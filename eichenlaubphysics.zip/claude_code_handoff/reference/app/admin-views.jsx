// Admin views: Assigned, Sessions, Settings + AdminApp orchestrator.
const { useState: useStateV, useMemo: useMemoV } = React;

function NoteField({ value, onSave }) {
  const [editing, setEditing] = useStateV(false);
  const [v, setV] = useStateV(value || '');
  if (editing) return <input className="note" style={{ border: 'none', borderBottom: '1px solid var(--accent)', borderRadius: 0, padding: '0 0 1px', background: 'transparent', width: 200, fontStyle: 'italic' }} value={v} autoFocus onChange={e => setV(e.target.value)} onBlur={() => { setEditing(false); onSave(v); }} onKeyDown={e => e.key === 'Enter' && e.target.blur()} placeholder="e.g. Ch. 1, problems 1–8" />;
  if (!v) return <span style={{ fontSize: 12.5, color: 'var(--muted)', cursor: 'text', fontStyle: 'italic', opacity: .7 }} onClick={() => setEditing(true)}>Add note…</span>;
  return <span className="note" style={{ cursor: 'text' }} onClick={() => setEditing(true)}>{v}</span>;
}

function AdminAssigned({ student, assignments, byId, onToggle, onUnassign, onNote, onEmail }) {
  const [filter, setFilter] = useStateV('all');
  const [dragId, setDragId] = useStateV(null);
  const [overId, setOverId] = useStateV(null);
  const [order, setOrder] = useStateV(null);

  const aCount = assignments.filter(a => a.status === 'assigned').length;
  const cCount = assignments.filter(a => a.status === 'completed').length;
  const assignedIds = assignments.filter(a => a.status === 'assigned').sort((a, b) => (b.assigned_date || '').localeCompare(a.assigned_date || '')).map(a => a.problem_id);
  const ord = order ? [...order.filter(id => assignedIds.includes(id)), ...assignedIds.filter(id => !order.includes(id))] : assignedIds;

  let rows = assignments.filter(a => filter === 'all' || a.status === filter);
  if (filter === 'assigned') rows = [...rows].sort((a, b) => ord.indexOf(a.problem_id) - ord.indexOf(b.problem_id));
  else rows = [...rows].sort((a, b) => (b.assigned_date || '').localeCompare(a.assigned_date || ''));
  const drag = filter === 'assigned';

  function drop(target) {
    if (!dragId || dragId === target) { setDragId(null); setOverId(null); return; }
    const n = [...ord]; const f = n.indexOf(dragId), t = n.indexOf(target);
    n.splice(f, 1); n.splice(t, 0, dragId); setOrder(n); setDragId(null); setOverId(null);
  }

  return (
    <div className="workspace scroll" style={{ width: '100%' }}>
      <div className="work-pad">
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 18, gap: 12 }}>
          <div>
            <h1 style={{ fontSize: 24, marginBottom: 4 }}>{student.name}'s Problems</h1>
            <p className="mono" style={{ fontSize: 13, color: 'var(--muted)' }}>{aCount} assigned · {cCount} completed</p>
          </div>
          {aCount > 0 && <button className="btn primary" onClick={onEmail}><Icon name="mail" size={15} /> Generate email ({aCount})</button>}
        </div>
        <div className="tabs">
          {[['all', 'All', assignments.length], ['assigned', 'Assigned', aCount], ['completed', 'Completed', cCount]].map(([k, l, c]) => (
            <button key={k} className={filter === k ? 'active' : ''} onClick={() => setFilter(k)}>{l}<span className="tc">{c}</span></button>
          ))}
        </div>
        {rows.length === 0 ? <div className="empty">No {filter !== 'all' ? filter : ''} problems.</div> : (
          <div className="list">
            {rows.map(a => {
              const p = byId[a.problem_id]; if (!p) return null;
              const isRes = p.type === 'Book' || p.type === 'Handout';
              return (
                <div key={a.id} className={`row ${dragId === a.problem_id ? 'dragging' : ''} ${overId === a.problem_id ? 'drag-over' : ''}`}
                  draggable={drag}
                  onDragStart={drag ? () => setDragId(a.problem_id) : undefined}
                  onDragOver={drag ? (e => { e.preventDefault(); if (a.problem_id !== dragId) setOverId(a.problem_id); }) : undefined}
                  onDrop={drag ? (e => { e.preventDefault(); drop(a.problem_id); }) : undefined}
                  onDragEnd={() => { setDragId(null); setOverId(null); }}>
                  {drag && <span className="grip" title="Drag to reorder"><Icon name="grip" size={15} /></span>}
                  <button className={`badge ${a.status} status-toggle`} onClick={() => onToggle(a.problem_id)} title="Click to toggle status">
                    {a.status === 'assigned' ? '→ Assigned' : '✓ Completed'}
                  </button>
                  <div className="row-info">
                    <span className="lab">{p.contest}{!isRes ? ` ${p.year} ${p.label}` : ''}</span>
                    <span className="nm">{p.name}</span>
                    <NoteField value={a.notes} onSave={v => onNote(a.id, v)} />
                    <span className="dt" style={{ marginLeft: 'auto' }}>{a.assigned_date}</span>
                  </div>
                  <div className="row-links">
                    {p.problemUrl && <a className="lnk" href={p.problemUrl} target="_blank" rel="noreferrer">{isRes ? 'PDF' : 'Problem'} <Icon name="ext" size={11} /></a>}
                    {p.solutionUrl && <a className="lnk" href={p.solutionUrl} target="_blank" rel="noreferrer">Solution <Icon name="ext" size={11} /></a>}
                    <button className="btn sm ghost" style={{ padding: '3px 6px', color: 'var(--muted)' }} onClick={() => onUnassign(a.problem_id)} title="Remove"><Icon name="x" size={13} /></button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

function AdminSessions({ student, sessions, onSave, onDelete }) {
  const [editId, setEditId] = useStateV(null);
  const [draft, setDraft] = useStateV({});
  const list = [...sessions].sort((a, b) => b.scheduled_at.localeCompare(a.scheduled_at));

  function startNew() {
    const now = new Date(); now.setMinutes(0, 0, 0);
    const id = 'new-' + Date.now();
    setEditId(id); setDraft({ id, student_id: student.id, scheduled_at: now.toISOString().slice(0, 16), summary: '', miro_board_url: '', tagsInput: '' });
  }
  function startEdit(s) { setEditId(s.id); setDraft({ ...s, scheduled_at: s.scheduled_at.slice(0, 16), tagsInput: (s.tags || []).join(', ') }); }
  function save() {
    const { tagsInput, ...rest } = draft;
    onSave({ ...rest, scheduled_at: new Date(draft.scheduled_at).toISOString(), tags: (tagsInput || '').split(',').map(t => t.trim()).filter(Boolean) });
    setEditId(null);
  }

  const FieldRow = ({ label, children, top }) => (
    <div style={{ display: 'flex', gap: 12, marginBottom: 10, alignItems: top ? 'flex-start' : 'center' }}>
      <label style={{ width: 96, flexShrink: 0, fontSize: 12.5, paddingTop: top ? 7 : 0 }}>{label}</label>{children}
    </div>
  );

  return (
    <div className="workspace scroll" style={{ width: '100%' }}>
      <div className="work-pad">
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 18 }}>
          <div>
            <h1 style={{ fontSize: 24, marginBottom: 4 }}>{student.name}'s Sessions</h1>
            <p className="mono" style={{ fontSize: 13, color: 'var(--muted)' }}>{sessions.length} sessions</p>
          </div>
          <button className="btn primary" onClick={startNew}><Icon name="plus" size={15} /> New session</button>
        </div>

        {editId && (
          <div className="card" style={{ padding: 18, marginBottom: 16, borderColor: 'var(--accent)' }}>
            <FieldRow label="Date & time"><input type="datetime-local" value={draft.scheduled_at || ''} onChange={e => setDraft(d => ({ ...d, scheduled_at: e.target.value }))} /></FieldRow>
            <FieldRow label="Whiteboard"><input type="url" style={{ flex: 1 }} value={draft.miro_board_url || ''} onChange={e => setDraft(d => ({ ...d, miro_board_url: e.target.value }))} placeholder="https://app.ziteboard.com/…" /></FieldRow>
            <FieldRow label="Summary" top><textarea rows={3} style={{ flex: 1, resize: 'vertical' }} value={draft.summary || ''} onChange={e => setDraft(d => ({ ...d, summary: e.target.value }))} placeholder="What did you cover?" /></FieldRow>
            <FieldRow label="Tags"><input style={{ flex: 1 }} value={draft.tagsInput || ''} onChange={e => setDraft(d => ({ ...d, tagsInput: e.target.value }))} placeholder="quantum mechanics, waves, IPhO" /></FieldRow>
            <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 6 }}>
              <button className="btn sm" onClick={() => setEditId(null)}>Cancel</button>
              <button className="btn sm primary" onClick={save}>Save</button>
            </div>
          </div>
        )}

        {list.length === 0 && !editId ? <div className="empty">No sessions yet. They appear automatically when booked, or add one manually.</div> : (
          <div className="list">
            {list.map(s => (
              <div key={s.id} className="card session-card">
                <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                  <span className="when" style={{ flex: 1 }}>{fmtDateTime(s.scheduled_at)}</span>
                  {s.miro_board_url && <a className="lnk" href={s.miro_board_url} target="_blank" rel="noreferrer">Whiteboard <Icon name="ext" size={11} /></a>}
                  <button className="btn sm ghost" style={{ padding: '3px 8px', color: 'var(--muted)' }} onClick={() => startEdit(s)}>Edit</button>
                  <button className="btn sm ghost" style={{ padding: '3px 6px', color: 'var(--muted)' }} onClick={() => onDelete(s.id)}><Icon name="x" size={13} /></button>
                </div>
                {s.summary && <p style={{ fontSize: 13, color: 'var(--ink-soft)', lineHeight: 1.55, margin: '8px 0 0' }}>{s.summary}</p>}
                {(s.tags || []).length > 0 && <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 10 }}>{s.tags.map(t => <span key={t} className="chip">{t}</span>)}</div>}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function AdminSettings({ students }) {
  return (
    <div className="workspace scroll" style={{ width: '100%' }}>
      <div className="work-pad" style={{ maxWidth: 640 }}>
        <h1 style={{ fontSize: 24, marginBottom: 22 }}>Settings</h1>
        <div style={{ marginBottom: 30 }}>
          <h3 style={{ fontFamily: 'var(--font-ui)', fontSize: 13.5, fontWeight: 600, color: 'var(--ink-soft)', marginBottom: 8 }}>Database connection</h3>
          <p style={{ fontSize: 12.5, color: 'var(--muted)', marginBottom: 12, lineHeight: 1.55 }}>Service key required for saving assignments and student data. Never share this key.</p>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
            <label style={{ width: 90, fontSize: 13, flexShrink: 0 }}>Service key</label>
            <input type="password" defaultValue="••••••••••••••••" className="mono" style={{ flex: 1 }} />
            <button className="btn">Save</button>
          </div>
        </div>
        <div>
          <h3 style={{ fontFamily: 'var(--font-ui)', fontSize: 13.5, fontWeight: 600, color: 'var(--ink-soft)', marginBottom: 10 }}>Students</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {students.map(s => (
              <div key={s.id} className="card" style={{ padding: 16 }}>
                <div style={{ display: 'flex', gap: 10, alignItems: 'center', marginBottom: 8 }}>
                  <label style={{ width: 54, fontSize: 12.5, color: 'var(--muted)' }}>Name</label>
                  <input defaultValue={s.name} style={{ flex: 1 }} />
                  <button className="btn sm danger">Remove</button>
                </div>
                <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
                  <label style={{ width: 54, fontSize: 12.5, color: 'var(--muted)' }}>Email</label>
                  <input defaultValue={s.email} style={{ flex: 1 }} />
                </div>
                {s.notes && <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 8, fontStyle: 'italic' }}>{s.notes}</p>}
              </div>
            ))}
          </div>
          <button className="btn" style={{ marginTop: 12 }}><Icon name="plus" size={14} /> Add student</button>
        </div>
      </div>
    </div>
  );
}

const DEFAULT_FILTERS = { contests: new Set(), types: new Set(), topics: new Set(), statuses: new Set(), selectedTags: new Set(), textSearch: '', hideCompleted: false };

function AdminApp({ data, onPreview }) {
  const [view, setView] = useStateV('problems');
  const [studentId, setStudentId] = useStateV('borna');
  const [filters, setFilters] = useStateV(DEFAULT_FILTERS);
  const [selected, setSelected] = useStateV(new Set());
  const [sort, setSort] = useStateV({ col: 'year', dir: 'desc' });
  const [assignments, setAssignments] = useStateV(data.assignments);
  const [sessions, setSessions] = useStateV(data.sessions);
  const [showToast, toastNode] = useToast();

  const students = data.students.filter(s => s.id !== 'mark').concat(data.students.filter(s => s.id === 'mark'));
  const student = students.find(s => s.id === studentId) || students[0];
  const allProblems = useMemoV(() => data.problems.concat(data.handouts), [data]);
  const byId = useMemoV(() => Object.fromEntries(allProblems.map(p => [p.id, p])), [allProblems]);
  const statusMap = useMemoV(() => { const m = {}; assignments.filter(a => a.student_id === studentId).forEach(a => m[a.problem_id] = a.status); return m; }, [assignments, studentId]);
  const myAssign = useMemoV(() => assignments.filter(a => a.student_id === studentId), [assignments, studentId]);
  const aCount = myAssign.filter(a => a.status === 'assigned').length;
  const mySessions = sessions.filter(s => s.student_id === studentId);

  function assign(ids) {
    const date = '2026-05-29';
    const add = ids.filter(id => !statusMap[id]).map(id => ({ id: 'x' + id + Date.now(), student_id: studentId, problem_id: id, status: 'assigned', assigned_date: date, completed_date: null, notes: '' }));
    if (!add.length) { showToast('Already assigned or completed'); setSelected(new Set()); return; }
    setAssignments(a => [...a, ...add]); setSelected(new Set());
    showToast(`Assigned ${add.length} problem${add.length > 1 ? 's' : ''} to ${student.name}`);
  }
  function toggleStatus(pid) {
    setAssignments(a => a.map(x => x.student_id === studentId && x.problem_id === pid ? { ...x, status: x.status === 'assigned' ? 'completed' : 'assigned', completed_date: x.status === 'assigned' ? '2026-05-29' : null } : x));
  }
  function unassign(pid) { setAssignments(a => a.filter(x => !(x.student_id === studentId && x.problem_id === pid))); showToast('Removed from assigned list'); }
  function note(id, v) { setAssignments(a => a.map(x => x.id === id ? { ...x, notes: v } : x)); }
  function saveSession(s) { setSessions(ss => { const ex = ss.find(x => x.id === s.id); return ex ? ss.map(x => x.id === s.id ? s : x) : [...ss, s]; }); showToast('Session saved'); }
  function delSession(id) { setSessions(ss => ss.filter(x => x.id !== id)); showToast('Session deleted'); }

  const navItems = [['problems', 'Problems', null], ['assigned', 'Assigned', aCount], ['sessions', 'Sessions', null], ['settings', 'Settings', null]];

  return (
    <div className="app">
      <div className="topbar">
        <Wordmark sub="Trajectory · Admin" />
        <div className="topnav" style={{ marginLeft: 8 }}>
          {navItems.map(([k, l, b]) => (
            <button key={k} className={view === k ? 'active' : ''} onClick={() => setView(k)}>{l}{b > 0 ? <span className="nav-badge">{b}</span> : null}</button>
          ))}
        </div>
        <div className="spacer" />
        <div className="student-pill">
          <label className="eyebrow" style={{ letterSpacing: '.08em' }}>Student</label>
          <select value={studentId} onChange={e => { setStudentId(e.target.value); setSelected(new Set()); }}>
            {students.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
          </select>
          <button className="btn sm ghost" style={{ color: 'var(--muted)', fontSize: 12 }} onClick={() => onPreview(studentId)} title="Preview student portal">↗ preview</button>
        </div>
      </div>
      <div className="content">
        {view === 'problems' && <ProblemBrowser allProblems={allProblems} filters={filters} setF={setFilters} statusMap={statusMap} selected={selected} setSelected={setSelected} sort={sort} setSort={setSort} student={student} onAssign={assign} />}
        {view === 'assigned' && <AdminAssigned student={student} assignments={myAssign} byId={byId} onToggle={toggleStatus} onUnassign={unassign} onNote={note} onEmail={() => showToast('Email draft generated')} />}
        {view === 'sessions' && <AdminSessions student={student} sessions={mySessions} onSave={saveSession} onDelete={delSession} />}
        {view === 'settings' && <AdminSettings students={data.students} />}
      </div>
      {toastNode}
    </div>
  );
}

Object.assign(window, { AdminApp });
