// Mock data derived from the real Trajectory dataset (problems.json, assignments.json, students.json).
window.DATA = {
 "problems": [
  {
   "id": "ipho-1982-T1",
   "contest": "IPhO",
   "year": 1982,
   "country": "West Germany",
   "type": "Theory",
   "label": "T1",
   "name": "Fluorescent Lamp",
   "desc": "Steady-state operation of a fluorescent lamp with ballast inductor; AC analysis and power.",
   "topic": "Electromagnetism",
   "tags": [
    "AC circuits",
    "inductor ballast",
    "gas discharge",
    "circuits"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_1982_Q1.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_1982_S1.pdf"
  },
  {
   "id": "ipho-2019-E1",
   "contest": "IPhO",
   "year": 2019,
   "country": "Israel",
   "type": "Experiment",
   "label": "E1",
   "name": "Optical Measurements",
   "desc": "Series of optical measurements involving polarization, refraction and birefringence.",
   "topic": "Experimental Methods",
   "tags": [
    "polarization",
    "Brewster angle",
    "birefringence"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2019_Q4.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2019_S4.pdf"
  },
  {
   "id": "ipho-2019-E2",
   "contest": "IPhO",
   "year": 2019,
   "country": "Israel",
   "type": "Experiment",
   "label": "E2",
   "name": "Wiedemann-Franz Law",
   "desc": "Verify the Wiedemann-Franz law by measuring thermal and electrical conductivity of a metal.",
   "topic": "Experimental Methods",
   "tags": [
    "Wiedemann-Franz",
    "thermal conductivity",
    "Lorenz number"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2019_Q5.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2019_S5.pdf"
  },
  {
   "id": "ipho-2022-E1",
   "contest": "IPhO",
   "year": 2022,
   "country": "Switzerland",
   "type": "Experiment",
   "label": "E1",
   "name": "Planet",
   "desc": "Measure planetary parameters using a tabletop analogue / model setup.",
   "topic": "Experimental Methods",
   "tags": [
    "analogue experiment",
    "Kepler's laws",
    "scaling"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2022_Q4.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2022_S4.pdf"
  },
  {
   "id": "ipho-2022-E2",
   "contest": "IPhO",
   "year": 2022,
   "country": "Switzerland",
   "type": "Experiment",
   "label": "E2",
   "name": "Cylindrical Diode",
   "desc": "Measure space-charge-limited current in a cylindrical thermionic diode (Child-Langmuir law).",
   "topic": "Experimental Methods",
   "tags": [
    "space charge",
    "Child-Langmuir",
    "thermionic emission"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2022_Q5.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2022_S5.pdf"
  },
  {
   "id": "ipho-2011-E2",
   "contest": "IPhO",
   "year": 2011,
   "country": "Thailand",
   "type": "Experiment",
   "label": "E2",
   "name": "Mechanical Black Box: Cylinder with a Ball Inside",
   "desc": "Determine internal contents (size and mass of ball) of a sealed cylinder via dynamic measurements.",
   "topic": "Experimental Methods",
   "tags": [
    "moment of inertia",
    "rolling motion",
    "black box"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2011_Q5.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2011_S5.pdf"
  },
  {
   "id": "ipho-2017-E1",
   "contest": "IPhO",
   "year": 2017,
   "country": "Indonesia",
   "type": "Experiment",
   "label": "E1",
   "name": "Optics of a Salt Solution",
   "desc": "Measure how refractive index of a salt solution depends on concentration, using a laser.",
   "topic": "Experimental Methods",
   "tags": [
    "refractive index",
    "concentration",
    "Snell's law"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2017_Q4.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2017_S4.pdf"
  },
  {
   "id": "ipho-2018-E2",
   "contest": "IPhO",
   "year": 2018,
   "country": "Portugal",
   "type": "Experiment",
   "label": "E2",
   "name": "Viscoelasticity of a Polymer Thread",
   "desc": "Investigate the viscoelastic response of a polymer thread under stretching and relaxation.",
   "topic": "Experimental Methods",
   "tags": [
    "viscoelasticity",
    "stress relaxation",
    "polymer"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2018_Q5.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2018_S5.pdf"
  },
  {
   "id": "usapho-2019-A1",
   "contest": "USAPhO",
   "year": 2019,
   "country": "",
   "type": "Theory",
   "label": "A1",
   "name": "Collision Course",
   "desc": "Two blocks slide down an inclined plane with different friction coefficients, collide elastically, and continue sliding. Analyzes the conditions for multiple collisions and the final speeds, with consideration of impulsive forces.",
   "topic": "Mechanics",
   "tags": [
    "elastic collision",
    "friction",
    "inclined plane",
    "impulse"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/2019_USAPhO.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/USAPhO-2019-Solutions.pdf"
  },
  {
   "id": "usapho-2019-A2",
   "contest": "USAPhO",
   "year": 2019,
   "country": "",
   "type": "Theory",
   "label": "A2",
   "name": "Green Revolution",
   "desc": "Models a wind turbine as a heat engine powered by temperature differences created by solar heating. Derives efficiency and power output using thermodynamic cycle analysis applied to the atmosphere.",
   "topic": "Thermodynamics",
   "tags": [
    "heat engine",
    "wind power",
    "solar heating",
    "atmospheric thermodynamics"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/2019_USAPhO.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/USAPhO-2019-Solutions.pdf"
  },
  {
   "id": "usapho-2019-A3",
   "contest": "USAPhO",
   "year": 2019,
   "country": "",
   "type": "Theory",
   "label": "A3",
   "name": "Electric Slide",
   "desc": "Analyzes space-charge-limited current transport in a semiconductor, where the electric field is modified by the charge of the carriers themselves. Covers both drift-dominated and diffusion-dominated transport regimes.",
   "topic": "Quantum Physics",
   "tags": [
    "space-charge",
    "semiconductor",
    "drift",
    "diffusion"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/2019_USAPhO.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/USAPhO-2019-Solutions.pdf"
  },
  {
   "id": "usapho-2019-B1",
   "contest": "USAPhO",
   "year": 2019,
   "country": "",
   "type": "Theory",
   "label": "B1",
   "name": "Strain in the Membrane",
   "desc": "Models a neuron cell membrane as an elastic capacitor that can deform under the electric field between its plates. Analyzes how ion pumps charge the membrane and under what conditions it becomes mechanically unstable and collapses.",
   "topic": "Electromagnetism",
   "tags": [
    "capacitor",
    "membrane",
    "elasticity",
    "electromechanical instability"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/2019_USAPhO.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/USAPhO-2019-Solutions.pdf"
  },
  {
   "id": "usapho-2019-B2",
   "contest": "USAPhO",
   "year": 2019,
   "country": "",
   "type": "Theory",
   "label": "B2",
   "name": "Stellar Black Box",
   "desc": "Uses the blackbody radiation spectrum from a star to determine its radius and temperature, combined with parallax to find its luminosity and distance. Also analyzes a planetary transit to determine the planet's radius.",
   "topic": "Astrophysics",
   "tags": [
    "blackbody radiation",
    "stellar parameters",
    "parallax",
    "luminosity"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/2019_USAPhO.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/USAPhO-2019-Solutions.pdf"
  },
  {
   "id": "usapho-2019-B3",
   "contest": "USAPhO",
   "year": 2019,
   "country": "",
   "type": "Theory",
   "label": "B3",
   "name": "Pitfall",
   "desc": "Analyzes the motion of a rigid rod pivoted at one end, constrained by a bead that can slide along the rod and a rail. The system acts like an inverted pendulum and the bead falls in a complex trajectory determined by constraint forces.",
   "topic": "Mechanics",
   "tags": [
    "rigid body",
    "bead on rod",
    "inverted pendulum",
    "Lagrangian mechanics"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/2019_USAPhO.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/USAPhO-2019-Solutions.pdf"
  },
  {
   "id": "ipho-2024-E2",
   "contest": "IPhO",
   "year": 2024,
   "country": "Iran",
   "type": "Experiment",
   "label": "E2",
   "name": "Diffraction from Phase Steps",
   "desc": "Diffraction of laser light from transparent step structures; deduce step heights from patterns.",
   "topic": "Experimental Methods",
   "tags": [
    "phase diffraction",
    "interference",
    "step height"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2024_Q5.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2024_S5.pdf"
  },
  {
   "id": "ipho-2018-T3",
   "contest": "IPhO",
   "year": 2018,
   "country": "Portugal",
   "type": "Theory",
   "label": "T3",
   "name": "Physics of Live Systems",
   "desc": "Biophysics: diffusion, scaling and energy considerations in living systems.",
   "topic": "Thermodynamics",
   "tags": [
    "diffusion",
    "biophysics",
    "scaling"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2018_Q3.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2018_S3.pdf"
  },
  {
   "id": "ipho-2022-T1",
   "contest": "IPhO",
   "year": 2022,
   "country": "Switzerland",
   "type": "Theory",
   "label": "T1",
   "name": "Permanent Magnets",
   "desc": "Theory and applications of permanent magnets; field of dipoles and stacked magnet configurations.",
   "topic": "Electromagnetism",
   "tags": [
    "magnetic dipole",
    "magnetization",
    "force between magnets"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2022_Q1.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2022_S1.pdf"
  },
  {
   "id": "ipho-2021-T2",
   "contest": "IPhO",
   "year": 2021,
   "country": "Lithuania",
   "type": "Theory",
   "label": "T2",
   "name": "Electrostatic Lens",
   "desc": "Focusing of charged particles by a cylindrical electrostatic lens; thin-lens analogy and aberrations.",
   "topic": "Optics",
   "tags": [
    "electrostatic lens",
    "charged particle optics",
    "focal length"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2021_Q2.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2021_S2.pdf"
  },
  {
   "id": "ipho-2023-E2",
   "contest": "IPhO",
   "year": 2023,
   "country": "Japan",
   "type": "Experiment",
   "label": "E2",
   "name": "Birefringence",
   "desc": "Measure birefringence of a sample using polarized light and a quarter-wave plate setup.",
   "topic": "Experimental Methods",
   "tags": [
    "birefringence",
    "polarization",
    "wave plate"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2023_Q5.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2023_S5.pdf"
  },
  {
   "id": "balkan-2022-1",
   "contest": "Balkan",
   "year": 2022,
   "country": "",
   "type": "Theory",
   "label": "1",
   "name": "Resistor Circuit",
   "desc": "A five-resistor network with an ammeter, voltmeter, and switch has its equivalent resistance, currents, voltages, and dissipated power determined for both switch states and for a periodic switching cycle.",
   "topic": "Electromagnetism",
   "tags": [
    "equivalent resistance",
    "Kirchhoff's laws",
    "power dissipation",
    "switch"
   ],
   "problemUrl": "https://drive.google.com/file/d/1xhWQxb-cYkwqfRsp1ugbhodnjle95TCf/view?usp=share_link",
   "solutionUrl": "https://drive.google.com/file/d/1M3P_qnM6NVhOHjFxzMFCmbFYRBcRYjhf/view?usp=share_link"
  },
  {
   "id": "balkan-2021-4",
   "contest": "Balkan",
   "year": 2021,
   "country": "",
   "type": "Theory",
   "label": "4",
   "name": "Electric Circuit with Lamp",
   "desc": "An incandescent lamp with a nonlinear temperature-dependent current-voltage characteristic is connected in series or parallel with a known resistor; use graphical load-line intersection to find operating currents.",
   "topic": "Electromagnetism",
   "tags": [
    "nonlinear I-V characteristic",
    "tungsten filament",
    "load line",
    "graphical method"
   ],
   "problemUrl": "https://balkanphysicalunion.info/?p=2120",
   "solutionUrl": "https://balkanphysicalunion.info/?p=2120"
  },
  {
   "id": "ipho-2003-T2",
   "contest": "IPhO",
   "year": 2003,
   "country": "Taiwan",
   "type": "Theory",
   "label": "T2",
   "name": "Piezoelectric Crystal Resonator",
   "desc": "Equivalent circuit and resonance of a piezoelectric crystal driven by an AC source.",
   "topic": "Electromagnetism",
   "tags": [
    "piezoelectric resonance",
    "equivalent circuit",
    "Q factor",
    "circuits"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2003_Q2.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2003_S2.pdf"
  },
  {
   "id": "ipho-1971-T3",
   "contest": "IPhO",
   "year": 1971,
   "country": "Bulgaria",
   "type": "Theory",
   "label": "T3",
   "name": "Batteries, Capacitors and Resistors in a Cube",
   "desc": "Circuit with elements on the edges of a cube; exploit symmetry to find currents, voltages and energy.",
   "topic": "Electromagnetism",
   "tags": [
    "circuit symmetry",
    "Kirchhoff's laws",
    "capacitor energy",
    "circuits"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_1971_Q3.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_1971_S3.pdf"
  },
  {
   "id": "ipho-2025-T1",
   "contest": "IPhO",
   "year": 2025,
   "country": "France",
   "type": "Theory",
   "label": "T1",
   "name": "Hydrogen and Galaxies",
   "desc": "21 cm line of hydrogen used to map galactic kinematics and infer rotation curves.",
   "topic": "Astrophysics",
   "tags": [
    "21 cm line",
    "galactic rotation",
    "Doppler effect"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_Q1.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_S1.pdf"
  },
  {
   "id": "usapho-2025-A1",
   "contest": "USAPhO",
   "year": 2025,
   "country": "",
   "type": "Theory",
   "label": "A1",
   "name": "Shake It",
   "desc": "Models the physics of animals shaking water off their fur, analyzing centripetal forces on water droplets and surface tension. Explores scaling laws relating body size to shaking frequency.",
   "topic": "Mechanics",
   "tags": [
    "surface tension",
    "centripetal force",
    "scaling laws",
    "droplets"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/USAPhO_Exam_25.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/2025-USAPhO-Exam_solutions.pdf"
  },
  {
   "id": "eupho-2025-T1",
   "contest": "EuPhO",
   "year": 2025,
   "country": "Bulgaria",
   "type": "Theory",
   "label": "T1",
   "name": "Sunny",
   "desc": "A problem involving geometrical optics and the path of sunlight - likely analyzing the illuminated spot geometry on a surface from an overhead or angled light source.",
   "topic": "Optics",
   "tags": [
    "optics",
    "ray optics",
    "illumination",
    "angle"
   ],
   "problemUrl": "https://eupho.ee/wp-content/uploads/2025/06/EuPhO_2025_Theory_ENG.pdf",
   "solutionUrl": "https://eupho.ee/wp-content/uploads/2025/06/EuPhO25_Theory_Solutions_20250616_1120.pdf"
  },
  {
   "id": "balkan-2025-1",
   "contest": "Balkan",
   "year": 2025,
   "country": "",
   "type": "Theory",
   "label": "1",
   "name": "Ohrid Swimming Marathon",
   "desc": "Five swimmers race 25 km past three checkpoints; compute average speeds, then find the minimum time for a support boat to intercept a swimmer before a control point, both starting from rest with constant accelerations.",
   "topic": "Mechanics",
   "tags": [
    "kinematics",
    "average speed",
    "constant acceleration",
    "quadratic equation"
   ],
   "problemUrl": "https://balkanphysicalunion.info/wp-content/uploads/2025/07/BPO7Problems.pdf",
   "solutionUrl": "https://balkanphysicalunion.info/wp-content/uploads/2025/07/BPO7Solutions.pdf"
  },
  {
   "id": "nbpho-2025-1",
   "contest": "NordicBalkan",
   "year": 2025,
   "country": "Estonia",
   "type": "Theory",
   "label": "1",
   "name": "Flying Dumbbell",
   "desc": "Analyzes the longitudinal oscillations and collision dynamics of a steel dumbbell (two balls connected by a rod) bouncing off a wall, including the effect of angle between the rod axis and the wall normal.",
   "topic": "Waves & Oscillations",
   "tags": [
    "elastic collision",
    "oscillation",
    "Young's modulus",
    "stress"
   ],
   "problemUrl": "https://nbpho.ee/wp-content/uploads/2025/04/NBPhO_2025_problems_V1.0.pdf",
   "solutionUrl": "https://nbpho.ee/wp-content/uploads/2025/04/00_NBPhO_2025_solutions_v1.0.pdf"
  },
  {
   "id": "ipho-2025-T2",
   "contest": "IPhO",
   "year": 2025,
   "country": "France",
   "type": "Theory",
   "label": "T2",
   "name": "Cox's Timepiece",
   "desc": "Mechanical clock driven by atmospheric pressure variations; energy harvesting and oscillator.",
   "topic": "Thermodynamics",
   "tags": [
    "atmospheric pressure",
    "mechanical oscillator",
    "energy harvesting"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_Q2.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_S2.pdf"
  },
  {
   "id": "usapho-2025-A2",
   "contest": "USAPhO",
   "year": 2025,
   "country": "",
   "type": "Theory",
   "label": "A2",
   "name": "Black Tides",
   "desc": "Analyzes tidal disruption events (TDEs), where a star passes too close to a supermassive black hole and is torn apart by tidal forces. Examines orbital mechanics and the tidal disruption radius.",
   "topic": "Astrophysics",
   "tags": [
    "tidal force",
    "black hole",
    "orbital mechanics",
    "tidal disruption"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/USAPhO_Exam_25.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/2025-USAPhO-Exam_solutions.pdf"
  },
  {
   "id": "eupho-2025-T2",
   "contest": "EuPhO",
   "year": 2025,
   "country": "Bulgaria",
   "type": "Theory",
   "label": "T2",
   "name": "Helix in magnetic field (unconfirmed title)",
   "desc": "A problem involving a charged particle moving in a helical trajectory in a magnetic field, based on evidence from the Scribd solutions document tagged \"Magnetic Field | Helix\" and an associated video solution by Jaan Kalda.",
   "topic": "Electromagnetism",
   "tags": [
    "magnetic field",
    "helix",
    "charged particle",
    "cyclotron motion"
   ],
   "problemUrl": "https://eupho.ee/wp-content/uploads/2025/06/EuPhO_2025_Theory_ENG.pdf",
   "solutionUrl": "https://eupho.ee/wp-content/uploads/2025/06/EuPhO25_Theory_Solutions_20250616_1120.pdf"
  },
  {
   "id": "balkan-2025-2",
   "contest": "Balkan",
   "year": 2025,
   "country": "",
   "type": "Theory",
   "label": "2",
   "name": "Star Wars",
   "desc": "An Earth satellite on an elliptical orbit undergoes a plastic collision with a radially-moving projectile at apogee, changing the eccentricity; find speeds at apogee and perigee, post-collision speeds, energy ratio, and projectile launch speed.",
   "topic": "Astrophysics",
   "tags": [
    "orbital mechanics",
    "elliptical orbit",
    "angular momentum conservation",
    "plastic collision"
   ],
   "problemUrl": "https://balkanphysicalunion.info/wp-content/uploads/2025/07/BPO7Problems.pdf",
   "solutionUrl": "https://balkanphysicalunion.info/wp-content/uploads/2025/07/BPO7Solutions.pdf"
  },
  {
   "id": "nbpho-2025-2",
   "contest": "NordicBalkan",
   "year": 2025,
   "country": "Estonia",
   "type": "Theory",
   "label": "2",
   "name": "Evaporation",
   "desc": "Studies evaporation of water from a wet surface in a sauna environment, connecting the Clausius-Clapeyron equation, vapor density, laminar flow, and thermal equilibrium to find the equilibrium skin temperature.",
   "topic": "Thermodynamics",
   "tags": [
    "Clausius-Clapeyron",
    "evaporation",
    "latent heat",
    "vapor pressure"
   ],
   "problemUrl": "https://nbpho.ee/wp-content/uploads/2025/04/NBPhO_2025_problems_V1.0.pdf",
   "solutionUrl": "https://nbpho.ee/wp-content/uploads/2025/04/00_NBPhO_2025_solutions_v1.0.pdf"
  },
  {
   "id": "ipho-2025-T3",
   "contest": "IPhO",
   "year": 2025,
   "country": "France",
   "type": "Theory",
   "label": "T3",
   "name": "Champagne!",
   "desc": "Physics of bubbles in champagne: nucleation, rise, growth and acoustic emission.",
   "topic": "Thermodynamics",
   "tags": [
    "bubble dynamics",
    "buoyancy",
    "Henry's law"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_Q3.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_S3.pdf"
  },
  {
   "id": "usapho-2025-A3",
   "contest": "USAPhO",
   "year": 2025,
   "country": "",
   "type": "Theory",
   "label": "A3",
   "name": "Bitter and Magnetic",
   "desc": "Explores the design of a Bitter electromagnet, a multi-layer solenoid wound from metal plates. Analyzes the mechanical stresses (pressure and tension) in the solenoid windings due to magnetic forces.",
   "topic": "Electromagnetism",
   "tags": [
    "solenoid",
    "electromagnet",
    "Bitter magnet",
    "magnetic pressure"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/USAPhO_Exam_25.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/2025-USAPhO-Exam_solutions.pdf"
  },
  {
   "id": "eupho-2025-T3",
   "contest": "EuPhO",
   "year": 2025,
   "country": "Bulgaria",
   "type": "Theory",
   "label": "T3",
   "name": "Adiabatic invariants / magnetic bottle (unconfirmed title)",
   "desc": "A problem related to adiabatic invariants in physics - the official EuPhO 2025 page explicitly links a supplementary document \"Adiabatic Invariants\" by Thomas Foster as a resource for Problem No. 3, and the solution describes \"phase trajectories analogous to field lines.\" This likely involves a charged particle trapped in a slowly varying magnetic field (magnetic mirror/bottle).",
   "topic": "Electromagnetism",
   "tags": [
    "adiabatic invariant",
    "magnetic field",
    "charged particle",
    "spiral motion"
   ],
   "problemUrl": "https://eupho.ee/wp-content/uploads/2025/06/EuPhO_2025_Theory_ENG.pdf",
   "solutionUrl": "https://eupho.ee/wp-content/uploads/2025/06/EuPhO25_Theory_Solutions_20250616_1120.pdf"
  },
  {
   "id": "balkan-2025-3",
   "contest": "Balkan",
   "year": 2025,
   "country": "",
   "type": "Theory",
   "label": "3",
   "name": "Charged Spheres and Springs",
   "desc": "Two identical charged spheres hang on insulating wires at 30 degrees; four charged spheres fixed at corners of a square with a fifth held above by four springs; find charge, energies, spring constant, and restoring force for small vertical oscillations.",
   "topic": "Electromagnetism",
   "tags": [
    "Coulomb's law",
    "electrostatics",
    "equilibrium",
    "spring constant"
   ],
   "problemUrl": "https://balkanphysicalunion.info/wp-content/uploads/2025/07/BPO7Problems.pdf",
   "solutionUrl": "https://balkanphysicalunion.info/wp-content/uploads/2025/07/BPO7Solutions.pdf"
  },
  {
   "id": "nbpho-2025-3",
   "contest": "NordicBalkan",
   "year": 2025,
   "country": "Estonia",
   "type": "Theory",
   "label": "3",
   "name": "Nuclear Reactors",
   "desc": "Covers thermal neutron fission reactors: neutron moderation, elastic collisions with moderator atoms, energy loss per collision, fission gas pressure buildup in fuel rods, and Xenon-135 production.",
   "topic": "Quantum Physics",
   "tags": [
    "nuclear fission",
    "neutron moderation",
    "elastic collision",
    "ideal gas"
   ],
   "problemUrl": "https://nbpho.ee/wp-content/uploads/2025/04/NBPhO_2025_problems_V1.0.pdf",
   "solutionUrl": "https://nbpho.ee/wp-content/uploads/2025/04/00_NBPhO_2025_solutions_v1.0.pdf"
  },
  {
   "id": "ipho-2025-E1",
   "contest": "IPhO",
   "year": 2025,
   "country": "France",
   "type": "Experiment",
   "label": "E1",
   "name": "Earth's Magnetic Field Measurement",
   "desc": "Determine the magnitude and direction of Earth's magnetic field using a coil/compass setup.",
   "topic": "Experimental Methods",
   "tags": [
    "geomagnetic field",
    "Helmholtz coil",
    "torque on dipole"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_Q4.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_S4.pdf"
  },
  {
   "id": "usapho-2025-B1",
   "contest": "USAPhO",
   "year": 2025,
   "country": "",
   "type": "Theory",
   "label": "B1",
   "name": "Scroll 'n' Roll",
   "desc": "An ant walks on a rotating disk that is free to spin on a frictionless surface. Uses conservation of angular momentum and linear momentum to analyze the motion of the ant and the disk.",
   "topic": "Mechanics",
   "tags": [
    "angular momentum",
    "conservation",
    "rotating disk",
    "ant"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/USAPhO_Exam_25.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/2025-USAPhO-Exam_solutions.pdf"
  },
  {
   "id": "eupho-2025-E1",
   "contest": "EuPhO",
   "year": 2025,
   "country": "Bulgaria",
   "type": "Experiment",
   "label": "E1",
   "name": "Unknown (experiment PDF combined with solutions)",
   "desc": "The experimental problem(s) for EuPhO 2025. AI benchmarking studies note that EuPhO 2025 featured \"optics problems with variable figures.\" Results sheets confirm two experimental scores (Experiment 1 and Experiment 2).",
   "topic": "Experimental Methods",
   "tags": [
    "optics",
    "experimental measurement"
   ],
   "problemUrl": "https://eupho.ee/wp-content/uploads/2025/06/EuPhO_2025_experiment.pdf",
   "solutionUrl": "https://eupho.ee/wp-content/uploads/2025/06/EuPhO25_Exp_Problems_Solutions_20250616_1120.pdf"
  },
  {
   "id": "balkan-2025-4",
   "contest": "Balkan",
   "year": 2025,
   "country": "",
   "type": "Theory",
   "label": "4",
   "name": "N Resistors and Ammeter",
   "desc": "An ammeter with internal resistance is embedded in a ladder network of N equal resistors; given 10 consecutive current readings, linearize the ammeter-current formula graphically to extract resistance values.",
   "topic": "Electromagnetism",
   "tags": [
    "ladder network",
    "Kirchhoff's laws",
    "ammeter resistance",
    "graphical linearization"
   ],
   "problemUrl": "https://balkanphysicalunion.info/wp-content/uploads/2025/07/BPO7Problems.pdf",
   "solutionUrl": "https://balkanphysicalunion.info/wp-content/uploads/2025/07/BPO7Solutions.pdf"
  },
  {
   "id": "nbpho-2025-4",
   "contest": "NordicBalkan",
   "year": 2025,
   "country": "Estonia",
   "type": "Experiment",
   "label": "4",
   "name": "Black Box",
   "desc": "Experimental problem: identify the internal circuit (three diodes and a resistor) inside a black box using multimeters and a voltage source; measure resistance and opening voltages of all diodes.",
   "topic": "Experimental Methods",
   "tags": [
    "black box",
    "diode",
    "resistor",
    "circuit"
   ],
   "problemUrl": "https://nbpho.ee/wp-content/uploads/2025/04/NBPhO_2025_problems_V1.0.pdf",
   "solutionUrl": "https://nbpho.ee/wp-content/uploads/2025/04/00_NBPhO_2025_solutions_v1.0.pdf"
  },
  {
   "id": "ipho-2025-E2",
   "contest": "IPhO",
   "year": 2025,
   "country": "France",
   "type": "Experiment",
   "label": "E2",
   "name": "Sand Craters and Dunes",
   "desc": "Granular physics experiment: crater formation from impacts and dune scaling laws.",
   "topic": "Experimental Methods",
   "tags": [
    "granular media",
    "impact crater",
    "scaling"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_Q5.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_S5.pdf"
  },
  {
   "id": "usapho-2025-B2",
   "contest": "USAPhO",
   "year": 2025,
   "country": "",
   "type": "Theory",
   "label": "B2",
   "name": "Where's the Kaboom?",
   "desc": "Studies how a sonic boom propagates through an atmosphere with a temperature (and hence sound speed) gradient. Analyzes the shape and direction of the Mach cone in a non-uniform medium.",
   "topic": "Optics",
   "tags": [
    "sonic boom",
    "Mach cone",
    "Mach number",
    "sound speed gradient"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/USAPhO_Exam_25.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/2025-USAPhO-Exam_solutions.pdf"
  },
  {
   "id": "eupho-2024-T1",
   "contest": "EuPhO",
   "year": 2024,
   "country": "Georgia",
   "type": "Theory",
   "label": "T1",
   "name": "Sliding puck",
   "desc": "A puck slides along a wall under friction and the normal force from the wall, causing it to both translate and rotate. The problem analyzes the coupled translational and rotational dynamics of this contact-friction system.",
   "topic": "Mechanics",
   "tags": [
    "friction",
    "rotation",
    "sliding",
    "normal force"
   ],
   "problemUrl": "https://eupho.ee/wp-content/uploads/2024/07/EuPhO_2024_theory_final.pdf",
   "solutionUrl": "https://eupho.ee/wp-content/uploads/2024/07/EuPhO_2024_theory_sol.pdf"
  },
  {
   "id": "balkan-2024-1",
   "contest": "Balkan",
   "year": 2024,
   "country": "",
   "type": "Theory",
   "label": "1",
   "name": "Bouncing Ball Stack",
   "desc": "A vertical stack of n balls (each much lighter than the one below) is dropped; derive the rebound height of the top ball as a function of n and find the minimum number of balls needed to reach 1 km or Earth's escape speed.",
   "topic": "Mechanics",
   "tags": [
    "elastic collision",
    "energy transfer",
    "sequential collisions",
    "escape velocity"
   ],
   "problemUrl": "https://balkanphysicalunion.info/wp-content/uploads/2024/08/BPO6-Problems.pdf",
   "solutionUrl": "https://balkanphysicalunion.info/wp-content/uploads/2024/08/BPO6-Solutions.pdf"
  },
  {
   "id": "nbpho-2025-5",
   "contest": "NordicBalkan",
   "year": 2025,
   "country": "Estonia",
   "type": "Theory",
   "label": "5",
   "name": "Throwing",
   "desc": "Two projectile/kinematics problems: (i) minimum speed for a ball thrown from rest to intercept a horizontally-accelerating drone; (ii) using scale measurements from a figure to find the launch speeds of two simultaneously thrown projectiles that collide in midair.",
   "topic": "Mechanics",
   "tags": [
    "projectile motion",
    "kinematics",
    "minimum speed",
    "interception"
   ],
   "problemUrl": "https://nbpho.ee/wp-content/uploads/2025/04/NBPhO_2025_problems_V1.0.pdf",
   "solutionUrl": "https://nbpho.ee/wp-content/uploads/2025/04/00_NBPhO_2025_solutions_v1.0.pdf"
  },
  {
   "id": "ipho-2025-T-Backup",
   "contest": "IPhO",
   "year": 2025,
   "country": "France",
   "type": "Theory",
   "label": "T-Backup",
   "name": "Strongly Correlated Fermi Gases (Theory Backup)",
   "desc": "Backup theory paper on ultracold strongly interacting Fermi gases; BCS-BEC crossover.",
   "topic": "Quantum Physics",
   "tags": [
    "BCS-BEC crossover",
    "Fermi gas",
    "ultracold atoms"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_Q6.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2025_S6.pdf"
  },
  {
   "id": "usapho-2025-B3",
   "contest": "USAPhO",
   "year": 2025,
   "country": "",
   "type": "Theory",
   "label": "B3",
   "name": "Locked and Moded",
   "desc": "Analyzes mode-locked lasers and Fabry-Perot resonators, connecting the time-domain and frequency-domain descriptions of light pulses. Uses uncertainty principle arguments relating pulse duration to spectral bandwidth.",
   "topic": "Quantum Physics",
   "tags": [
    "mode-locked laser",
    "Fabry-Perot",
    "uncertainty principle",
    "Fourier transform"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/USAPhO_Exam_25.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/2025-USAPhO-Exam_solutions.pdf"
  },
  {
   "id": "eupho-2024-T2",
   "contest": "EuPhO",
   "year": 2024,
   "country": "Georgia",
   "type": "Theory",
   "label": "T2",
   "name": "Relativistic Doppler / Subluminal signals",
   "desc": "Students analyze the relativistic Doppler effect for signals traveling at subluminal speeds between two reference frames in relative motion, applying Lorentz transformations and relativistic kinematics.",
   "topic": "Relativity",
   "tags": [
    "special relativity",
    "Doppler effect",
    "Lorentz transformation",
    "reference frames"
   ],
   "problemUrl": "https://eupho.ee/wp-content/uploads/2024/07/EuPhO_2024_theory_final.pdf",
   "solutionUrl": "https://eupho.ee/wp-content/uploads/2024/07/EuPhO_2024_theory_sol.pdf"
  },
  {
   "id": "balkan-2024-2",
   "contest": "Balkan",
   "year": 2024,
   "country": "",
   "type": "Theory",
   "label": "2",
   "name": "Ball on Curved Spring Track",
   "desc": "A ball on a quarter-circle frictionless track is connected to a spring; starting from rest at 45 degrees above horizontal, it reaches maximum speed at 34 degrees below horizontal; find spring lengths, forces, ball mass, and speeds at key points.",
   "topic": "Mechanics",
   "tags": [
    "circular track",
    "spring force",
    "energy conservation",
    "maximum speed"
   ],
   "problemUrl": "https://balkanphysicalunion.info/wp-content/uploads/2024/08/BPO6-Problems.pdf",
   "solutionUrl": "https://balkanphysicalunion.info/wp-content/uploads/2024/08/BPO6-Solutions.pdf"
  },
  {
   "id": "nbpho-2025-6",
   "contest": "NordicBalkan",
   "year": 2025,
   "country": "Estonia",
   "type": "Theory",
   "label": "6",
   "name": "Birds",
   "desc": "A long floating horizontal beam is loaded by a bird landing on one end; finds the maximum number of birds the beam can support while still floating, using Archimedes' principle and torque balance.",
   "topic": "Mechanics",
   "tags": [
    "buoyancy",
    "Archimedes",
    "torque",
    "floating beam"
   ],
   "problemUrl": "https://nbpho.ee/wp-content/uploads/2025/04/NBPhO_2025_problems_V1.0.pdf",
   "solutionUrl": "https://nbpho.ee/wp-content/uploads/2025/04/00_NBPhO_2025_solutions_v1.0.pdf"
  },
  {
   "id": "ipho-2024-T1",
   "contest": "IPhO",
   "year": 2024,
   "country": "Iran",
   "type": "Theory",
   "label": "T1",
   "name": "Greenhouse Effect",
   "desc": "Radiative balance of Earth-atmosphere system; greenhouse effect and equilibrium temperature.",
   "topic": "Optics",
   "tags": [
    "radiative balance",
    "Stefan-Boltzmann",
    "albedo"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2024_Q1.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2024_S1.pdf"
  },
  {
   "id": "usapho-2024-A1",
   "contest": "USAPhO",
   "year": 2024,
   "country": "",
   "type": "Theory",
   "label": "A1",
   "name": "Ping Pong",
   "desc": "Models an LC circuit formed by a solenoid connected to two charged spheres, analyzing oscillation frequency and radiation damping. Estimates the number of oscillations before half the electromagnetic energy is radiated away.",
   "topic": "Electromagnetism",
   "tags": [
    "LC circuit",
    "solenoid",
    "capacitance",
    "oscillation"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/USAPhO_Exam_24.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/2024-USAPhO-Exam_solutions.pdf"
  },
  {
   "id": "eupho-2024-T3",
   "contest": "EuPhO",
   "year": 2024,
   "country": "Georgia",
   "type": "Theory",
   "label": "T3",
   "name": "Fabry-Perot interferometer",
   "desc": "Analysis of a Fabry-Perot etalon (two parallel partially-reflecting mirrors), including resonance conditions, transmission spectrum, finesse, and free spectral range. Tagged as \"Electromagnetic Radiation\" on Scribd.",
   "topic": "Optics",
   "tags": [
    "Fabry-Perot",
    "interferometer",
    "etalon",
    "thin film"
   ],
   "problemUrl": "https://eupho.ee/wp-content/uploads/2024/07/EuPhO_2024_theory_final.pdf",
   "solutionUrl": "https://eupho.ee/wp-content/uploads/2024/07/EuPhO_2024_theory_sol.pdf"
  },
  {
   "id": "balkan-2024-3",
   "contest": "Balkan",
   "year": 2024,
   "country": "",
   "type": "Theory",
   "label": "3",
   "name": "Charged Pendulum with External Charge",
   "desc": "A charged ball rotates on a thread at 30 degrees to the vertical; an additional fixed charge is placed on the rotation axis at three different heights; find tension, angular speed, and period for each configuration.",
   "topic": "Electromagnetism",
   "tags": [
    "Coulomb's law",
    "circular motion",
    "conical pendulum",
    "electrostatic force"
   ],
   "problemUrl": "https://balkanphysicalunion.info/wp-content/uploads/2024/08/BPO6-Problems.pdf",
   "solutionUrl": "https://balkanphysicalunion.info/wp-content/uploads/2024/08/BPO6-Solutions.pdf"
  },
  {
   "id": "nbpho-2025-7",
   "contest": "NordicBalkan",
   "year": 2025,
   "country": "Estonia",
   "type": "Theory",
   "label": "7",
   "name": "Charged Rod",
   "desc": "A homogeneously charged rod of mass m in a uniform magnetic field (B along z-axis, rod in xy-plane) is subject only to the Lorentz force; finds the motion including the angular speed for zero tension at the center, and the trajectory when one end starts at the origin with given initial velocity.",
   "topic": "Electromagnetism",
   "tags": [
    "Lorentz force",
    "magnetic field",
    "rigid body",
    "rotation"
   ],
   "problemUrl": "https://nbpho.ee/wp-content/uploads/2025/04/NBPhO_2025_problems_V1.0.pdf",
   "solutionUrl": "https://nbpho.ee/wp-content/uploads/2025/04/00_NBPhO_2025_solutions_v1.0.pdf"
  },
  {
   "id": "ipho-2024-T2",
   "contest": "IPhO",
   "year": 2024,
   "country": "Iran",
   "type": "Theory",
   "label": "T2",
   "name": "Trapping Ions and Cooling Atoms",
   "desc": "Paul trap and laser cooling of ions/atoms; secular motion and Doppler limit.",
   "topic": "Quantum Physics",
   "tags": [
    "Paul trap",
    "laser cooling",
    "secular motion"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2024_Q2.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2024_S2.pdf"
  },
  {
   "id": "usapho-2024-A2",
   "contest": "USAPhO",
   "year": 2024,
   "country": "",
   "type": "Theory",
   "label": "A2",
   "name": "Stellar Stability",
   "desc": "Investigates the conditions for hydrostatic stability of a star using a polytropic equation of state (P proportional to density to the gamma power). Applies to giant stars with radiation pressure and to white dwarfs with quantum electron pressure.",
   "topic": "Astrophysics",
   "tags": [
    "stellar stability",
    "hydrostatic equilibrium",
    "polytrope",
    "white dwarf"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/USAPhO_Exam_24.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/2024-USAPhO-Exam_solutions.pdf"
  },
  {
   "id": "eupho-2024-E1",
   "contest": "EuPhO",
   "year": 2024,
   "country": "Georgia",
   "type": "Experiment",
   "label": "E1",
   "name": "Piezoelectricity",
   "desc": "Students investigate the piezoelectric properties of a crystal - measuring how mechanical deformation produces electric charge (and vice versa) - and use the piezoelectric crystal as a sensor to study the deformation of an elastic ball dropped onto the crystal.",
   "topic": "Experimental Methods",
   "tags": [
    "piezoelectricity",
    "crystal",
    "electric charge",
    "mechanical stress"
   ],
   "problemUrl": "https://eupho.ee/wp-content/uploads/2024/07/EuPhO_2024_experiment_final.pdf",
   "solutionUrl": "https://eupho.ee/wp-content/uploads/2024/07/EuPhO_2024_ep_sol.pdf"
  },
  {
   "id": "balkan-2024-4",
   "contest": "Balkan",
   "year": 2024,
   "country": "",
   "type": "Theory",
   "label": "4",
   "name": "Slinky Stretch",
   "desc": "A slinky of N turns rests on a horizontal surface with n turns hanging freely; hanging length is measured as a function of n and fitted to a quadratic formula; derive the theoretical form and extract stiffness and natural length per turn.",
   "topic": "Mechanics",
   "tags": [
    "spring constant",
    "slinky",
    "graphical linearization",
    "data fitting"
   ],
   "problemUrl": "https://balkanphysicalunion.info/wp-content/uploads/2024/08/BPO6-Problems.pdf",
   "solutionUrl": "https://balkanphysicalunion.info/wp-content/uploads/2024/08/BPO6-Solutions.pdf"
  },
  {
   "id": "nbpho-2025-8",
   "contest": "NordicBalkan",
   "year": 2025,
   "country": "Estonia",
   "type": "Theory",
   "label": "8",
   "name": "Phase Spiral",
   "desc": "Studies the \"phase spiral\" structure observed in Milky Way stars' vertical motion (z-velocity vs. z-position phase space), modeling galactic gravity as an infinite slab, estimating local dark matter density, and determining when the galactic perturbation occurred.",
   "topic": "Astrophysics",
   "tags": [
    "galactic dynamics",
    "dark matter",
    "phase space",
    "oscillation period"
   ],
   "problemUrl": "https://nbpho.ee/wp-content/uploads/2025/04/NBPhO_2025_problems_V1.0.pdf",
   "solutionUrl": "https://nbpho.ee/wp-content/uploads/2025/04/00_NBPhO_2025_solutions_v1.0.pdf"
  },
  {
   "id": "ipho-2024-T3",
   "contest": "IPhO",
   "year": 2024,
   "country": "Iran",
   "type": "Theory",
   "label": "T3",
   "name": "Black Widow Pulsar",
   "desc": "Mass loss and orbital evolution in a black widow pulsar binary system.",
   "topic": "Astrophysics",
   "tags": [
    "pulsar",
    "mass transfer",
    "orbital evolution"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2024_Q3.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2024_S3.pdf"
  },
  {
   "id": "usapho-2024-A3",
   "contest": "USAPhO",
   "year": 2024,
   "country": "",
   "type": "Theory",
   "label": "A3",
   "name": "Tilt Shift",
   "desc": "Analyzes image formation by an ideal converging lens, including magnification, focus blur due to finite aperture, diffraction blur, and photon shot noise in digital sensors. Finds conditions for geometric vs. diffraction-limited imaging.",
   "topic": "Quantum Physics",
   "tags": [
    "lens",
    "optics",
    "magnification",
    "aperture"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/USAPhO_Exam_24.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/2024-USAPhO-Exam_solutions.pdf"
  },
  {
   "id": "eupho-2023-T1",
   "contest": "EuPhO",
   "year": 2023,
   "country": "Germany",
   "type": "Theory",
   "label": "T1",
   "name": "Thermal lens",
   "desc": "An intense laser beam passes through a semitransparent medium, locally heating it and creating a radial refractive-index gradient. This temperature-dependent index variation acts as a lens (the \"thermal lens\" effect), and students analyze the resulting focusing or defocusing of the beam.",
   "topic": "Optics",
   "tags": [
    "thermal lens",
    "refractive index",
    "temperature gradient",
    "laser beam"
   ],
   "problemUrl": "https://eupho.ee/wp-content/uploads/2023/06/EuPhO_2023_theory.pdf",
   "solutionUrl": "https://eupho.ee/wp-content/uploads/2023/06/EuPhO_2023_theo_sol.pdf"
  },
  {
   "id": "balkan-2023-1",
   "contest": "Balkan",
   "year": 2023,
   "country": "",
   "type": "Theory",
   "label": "1",
   "name": "Springs and Nonlinear Force",
   "desc": "A conservative force pulls a body tangentially over a smooth hemisphere and a nonlinear spring drives a mass on a surface; compute work done over a path and find speed at a given elongation.",
   "topic": "Mechanics",
   "tags": [
    "work-energy theorem",
    "conservative forces",
    "nonlinear spring",
    "potential energy"
   ],
   "problemUrl": "https://balkanphysicalunion.info/wp-content/uploads/2023/06/Final-Problems_BPO5_ENG.pdf",
   "solutionUrl": "https://balkanphysicalunion.info/wp-content/uploads/2023/06/Final-Solutions_BPO5_ENG.pdf"
  },
  {
   "id": "nbpho-2025-9",
   "contest": "NordicBalkan",
   "year": 2025,
   "country": "Estonia",
   "type": "Experiment",
   "label": "9",
   "name": "Hot Plate",
   "desc": "Experimental problem using a resistor-heated foam plate and two aluminum plates (one polished, one anodized black); measures emissivity of polished aluminum, heat transfer coefficient, heat capacity, and heat conductance of silicone rubber pads.",
   "topic": "Experimental Methods",
   "tags": [
    "thermal radiation",
    "emissivity",
    "Stefan-Boltzmann",
    "heat transfer"
   ],
   "problemUrl": "https://nbpho.ee/wp-content/uploads/2025/04/NBPhO_2025_problems_V1.0.pdf",
   "solutionUrl": "https://nbpho.ee/wp-content/uploads/2025/04/00_NBPhO_2025_solutions_v1.0.pdf"
  },
  {
   "id": "ipho-2024-E1",
   "contest": "IPhO",
   "year": 2024,
   "country": "Iran",
   "type": "Experiment",
   "label": "E1",
   "name": "Heat Conduction in a Copper Rod",
   "desc": "Measure temperature profile along a copper rod and extract its thermal conductivity.",
   "topic": "Experimental Methods",
   "tags": [
    "Fourier's law",
    "thermal conductivity",
    "steady state"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2024_Q4.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2024_S4.pdf"
  },
  {
   "id": "usapho-2024-B1",
   "contest": "USAPhO",
   "year": 2024,
   "country": "",
   "type": "Theory",
   "label": "B1",
   "name": "The Muon Shot",
   "desc": "Analyzes relativistic muon physics in the context of a proposed muon collider. Covers center-of-mass energy thresholds, relativistic time dilation and decay probability, and collision rates in circular storage rings.",
   "topic": "Relativity",
   "tags": [
    "muon",
    "muon collider",
    "special relativity",
    "time dilation"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/USAPhO_Exam_24.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/2024-USAPhO-Exam_solutions.pdf"
  },
  {
   "id": "eupho-2023-T2",
   "contest": "EuPhO",
   "year": 2023,
   "country": "Germany",
   "type": "Theory",
   "label": "T2",
   "name": "A brick between planes",
   "desc": "A brick is squeezed between two inclined planes (or horizontal surfaces), and students analyze the forces, friction, and conditions for equilibrium or sliding, including the normal forces on the top and bottom surfaces.",
   "topic": "Mechanics",
   "tags": [
    "statics",
    "friction",
    "normal force",
    "wedge"
   ],
   "problemUrl": "https://eupho.ee/wp-content/uploads/2023/06/EuPhO_2023_theory.pdf",
   "solutionUrl": "https://eupho.ee/wp-content/uploads/2023/06/EuPhO_2023_theo_sol.pdf"
  },
  {
   "id": "balkan-2023-2",
   "contest": "Balkan",
   "year": 2023,
   "country": "",
   "type": "Theory",
   "label": "2",
   "name": "Plank on Rough Patch",
   "desc": "A plank on a smooth surface is launched or pulled by a constant force across a finite rough region; find minimum launch and applied-force thresholds for the plank to fully traverse the rough area.",
   "topic": "Mechanics",
   "tags": [
    "friction",
    "impulse-momentum",
    "work-energy",
    "force threshold"
   ],
   "problemUrl": "https://balkanphysicalunion.info/wp-content/uploads/2023/06/Final-Problems_BPO5_ENG.pdf",
   "solutionUrl": "https://balkanphysicalunion.info/wp-content/uploads/2023/06/Final-Solutions_BPO5_ENG.pdf"
  },
  {
   "id": "nbpho-2024-1",
   "contest": "NordicBalkan",
   "year": 2024,
   "country": "Estonia",
   "type": "Theory",
   "label": "1",
   "name": "Four Charges",
   "desc": "Four identical charged particles start at the corners of a square with equal-magnitude initial velocities pointing inward; finds the final speed and direction of each particle after the system evolves.",
   "topic": "Electromagnetism",
   "tags": [
    "electrostatics",
    "Coulomb force",
    "conservation of energy",
    "conservation of momentum"
   ],
   "problemUrl": "https://nbpho.ee/wp-content/uploads/2024/04/NBPhO_2024_problems_v1.0.pdf",
   "solutionUrl": "https://nbpho.ee/wp-content/uploads/2024/04/NBPhO_2024_solutions_v0.98.pdf"
  },
  {
   "id": "ipho-2023-T1",
   "contest": "IPhO",
   "year": 2023,
   "country": "Japan",
   "type": "Theory",
   "label": "T1",
   "name": "Soil Colloids",
   "desc": "Charged colloidal particles in soil; Debye screening, sedimentation and diffusion equilibrium.",
   "topic": "Thermodynamics",
   "tags": [
    "Debye length",
    "colloid",
    "diffusion"
   ],
   "problemUrl": "https://ipho.olimpicos.net/pdf/IPhO_2023_Q1.pdf",
   "solutionUrl": "https://ipho.olimpicos.net/pdf/IPhO_2023_S1.pdf"
  },
  {
   "id": "usapho-2024-B2",
   "contest": "USAPhO",
   "year": 2024,
   "country": "",
   "type": "Theory",
   "label": "B2",
   "name": "Solid Heat",
   "desc": "Two independent parts: (a) quantum corrections to heat capacity in an Einstein solid, starting from entropy and deriving the leading-order quantum correction to CV; (b) a gas-piston system where the piston is a classical solid, finding equilibrium and oscillation frequency.",
   "topic": "Quantum Physics",
   "tags": [
    "heat capacity",
    "Einstein solid",
    "quantum correction",
    "entropy"
   ],
   "problemUrl": "https://aapt.org/physicsteam/upload/USAPhO_Exam_24.pdf",
   "solutionUrl": "https://aapt.org/physicsteam/upload/2024-USAPhO-Exam_solutions.pdf"
  },
  {
   "id": "eupho-2023-T3",
   "contest": "EuPhO",
   "year": 2023,
   "country": "Germany",
   "type": "Theory",
   "label": "T3",
   "name": "Plate between magnets",
   "desc": "A conducting metal plate moves through the gap of a magnet. Induced eddy currents interact with the magnetic field to produce a braking (Lorentz) force. Students analyze the induced current distribution, the magnetic braking force, and related electromagnetic induction effects.",
   "topic": "Electromagnetism",
   "tags": [
    "eddy currents",
    "magnetic braking",
    "electromagnetic induction",
    "Lorentz force"
   ],
   "problemUrl": "https://eupho.ee/wp-content/uploads/2023/06/EuPhO_2023_theory.pdf",
   "solutionUrl": "https://eupho.ee/wp-content/uploads/2023/06/EuPhO_2023_theo_sol.pdf"
  },
  {
   "id": "balkan-2023-3",
   "contest": "Balkan",
   "year": 2023,
   "country": "",
   "type": "Theory",
   "label": "3",
   "name": "Tennis Ball Collision",
   "desc": "A tennis ball is dropped while a grasshopper jumps upward; they collide when the ball speed is twice the grasshopper speed; a horizontal tennis serve must also clear a net at 15 m.",
   "topic": "Mechanics",
   "tags": [
    "projectile motion",
    "collision kinematics",
    "relative velocity",
    "parabolic trajectory"
   ],
   "problemUrl": "https://balkanphysicalunion.info/wp-content/uploads/2023/06/Final-Problems_BPO5_ENG.pdf",
   "solutionUrl": "https://balkanphysicalunion.info/wp-content/uploads/2023/06/Final-Solutions_BPO5_ENG.pdf"
  },
  {
   "id": "nbpho-2024-2",
   "contest": "NordicBalkan",
   "year": 2024,
   "country": "Estonia",
   "type": "Theory",
   "label": "2",
   "name": "Oklo Fission Reactor",
   "desc": "Analyzes the natural nuclear fission reactor that operated in Oklo, Gabon ~1.8 billion years ago; calculates the historical abundance of U-235, the reactor's power, and total water mass consumed as moderator.",
   "topic": "Quantum Physics",
   "tags": [
    "nuclear fission",
    "U-235",
    "radioactive decay",
    "moderator"
   ],
   "problemUrl": "https://nbpho.ee/wp-content/uploads/2024/04/NBPhO_2024_problems_v1.0.pdf",
   "solutionUrl": "https://nbpho.ee/wp-content/uploads/2024/04/NBPhO_2024_solutions_v0.98.pdf"
  }
 ],
 "assignments": [
  {
   "id": "a-0",
   "student_id": "borna",
   "problem_id": "ipho-1982-T1",
   "status": "assigned",
   "assigned_date": "2026-05-26",
   "completed_date": null,
   "notes": "Start with the energy method"
  },
  {
   "id": "a-1",
   "student_id": "borna",
   "problem_id": "ipho-2019-E1",
   "status": "completed",
   "assigned_date": "2026-04-08",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-2",
   "student_id": "borna",
   "problem_id": "ipho-2019-E2",
   "status": "completed",
   "assigned_date": "2026-04-08",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-3",
   "student_id": "borna",
   "problem_id": "ipho-2022-E1",
   "status": "completed",
   "assigned_date": "2026-04-10",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-4",
   "student_id": "borna",
   "problem_id": "ipho-2022-E2",
   "status": "completed",
   "assigned_date": "2026-04-10",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-5",
   "student_id": "borna",
   "problem_id": "ipho-2011-E2",
   "status": "completed",
   "assigned_date": "2026-04-10",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-6",
   "student_id": "borna",
   "problem_id": "ipho-2017-E1",
   "status": "completed",
   "assigned_date": "2026-04-10",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-7",
   "student_id": "borna",
   "problem_id": "ipho-2018-E2",
   "status": "completed",
   "assigned_date": "2026-04-10",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-8",
   "student_id": "borna",
   "problem_id": "usapho-2019-A1",
   "status": "completed",
   "assigned_date": "2026-05-06",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-9",
   "student_id": "borna",
   "problem_id": "usapho-2019-A2",
   "status": "completed",
   "assigned_date": "2026-05-06",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-10",
   "student_id": "borna",
   "problem_id": "usapho-2019-A3",
   "status": "completed",
   "assigned_date": "2026-05-06",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-11",
   "student_id": "borna",
   "problem_id": "usapho-2019-B1",
   "status": "completed",
   "assigned_date": "2026-05-06",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-12",
   "student_id": "borna",
   "problem_id": "usapho-2019-B2",
   "status": "completed",
   "assigned_date": "2026-05-06",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-13",
   "student_id": "borna",
   "problem_id": "usapho-2019-B3",
   "status": "completed",
   "assigned_date": "2026-05-06",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-14",
   "student_id": "borna",
   "problem_id": "ipho-2024-E2",
   "status": "completed",
   "assigned_date": "2026-05-07",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-15",
   "student_id": "borna",
   "problem_id": "ipho-2018-T3",
   "status": "completed",
   "assigned_date": "2026-05-19",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-16",
   "student_id": "borna",
   "problem_id": "ipho-2022-T1",
   "status": "completed",
   "assigned_date": "2026-05-23",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-17",
   "student_id": "borna",
   "problem_id": "ipho-2021-T2",
   "status": "completed",
   "assigned_date": "2026-05-23",
   "completed_date": "2026-05-26",
   "notes": ""
  },
  {
   "id": "a-18",
   "student_id": "borna",
   "problem_id": "ipho-2023-E2",
   "status": "assigned",
   "assigned_date": "2026-05-27",
   "completed_date": null,
   "notes": ""
  },
  {
   "id": "a-19",
   "student_id": "borna",
   "problem_id": "balkan-2022-1",
   "status": "assigned",
   "assigned_date": "2026-05-27",
   "completed_date": null,
   "notes": "Try the rotating-frame approach we discussed"
  },
  {
   "id": "a-20",
   "student_id": "borna",
   "problem_id": "balkan-2021-4",
   "status": "assigned",
   "assigned_date": "2026-05-27",
   "completed_date": null,
   "notes": ""
  },
  {
   "id": "a-21",
   "student_id": "borna",
   "problem_id": "ipho-2003-T2",
   "status": "assigned",
   "assigned_date": "2026-05-27",
   "completed_date": null,
   "notes": "Part (c) is the interesting one"
  },
  {
   "id": "a-22",
   "student_id": "borna",
   "problem_id": "ipho-1971-T3",
   "status": "assigned",
   "assigned_date": "2026-05-27",
   "completed_date": null,
   "notes": ""
  }
 ],
 "sessions": [
  {
   "id": "s-1",
   "student_id": "borna",
   "scheduled_at": "2026-05-30T16:00:00.000Z",
   "summary": "",
   "tags": [],
   "miro_board_url": "",
   "miro_pdf_url": ""
  },
  {
   "id": "s-2",
   "student_id": "borna",
   "scheduled_at": "2026-05-26T16:00:00.000Z",
   "summary": "Worked through the 2023 IPhO experimental problem on diffusion. Borna had a strong instinct for the dimensional analysis; we tightened up the error-propagation write-up and discussed how to present uncertainty in the final figure.",
   "tags": [
    "experimental methods",
    "error analysis",
    "diffusion",
    "IPhO"
   ],
   "miro_board_url": "#",
   "miro_pdf_url": "#"
  },
  {
   "id": "s-3",
   "student_id": "borna",
   "scheduled_at": "2026-05-23T16:00:00.000Z",
   "summary": "Covered rotational dynamics: the 2022 IPhO theory problem and a Balkan angular-momentum question. Key idea today was choosing the right axis before writing torques. Assigned two follow-ups to consolidate.",
   "tags": [
    "mechanics",
    "rotation",
    "angular momentum",
    "torque"
   ],
   "miro_board_url": "#",
   "miro_pdf_url": "#"
  },
  {
   "id": "s-4",
   "student_id": "borna",
   "scheduled_at": "2026-05-19T16:00:00.000Z",
   "summary": "Thermodynamics review ahead of qualifying exam. Heat engines, entropy, and a careful look at quasi-static vs irreversible processes. Borna is ready to attempt full past papers.",
   "tags": [
    "thermodynamics",
    "entropy",
    "heat engines",
    "exam prep"
   ],
   "miro_board_url": "#",
   "miro_pdf_url": "#"
  },
  {
   "id": "s-5",
   "student_id": "borna",
   "scheduled_at": "2026-05-06T16:00:00.000Z",
   "summary": "First full USAPhO mock under timed conditions. Discussed pacing and when to abandon a part and move on. Strong on electromagnetism, wants more practice with optics.",
   "tags": [
    "USAPhO",
    "exam strategy",
    "electromagnetism",
    "optics"
   ],
   "miro_board_url": "#",
   "miro_pdf_url": "#"
  }
 ],
 "students": [
  {
   "id": "borna",
   "name": "Borna",
   "email": "borna.curic09@gmail.com",
   "notes": ""
  },
  {
   "id": "mark",
   "name": "Mark",
   "email": "mark.d.eichenlaub@gmail.com",
   "notes": "Teacher / familiar with many problems"
  },
  {
   "id": "leo",
   "name": "Leo",
   "email": "leo@example.com",
   "notes": "New — starting mechanics track"
  },
  {
   "id": "amara",
   "name": "Amara",
   "email": "amara@example.com",
   "notes": "Prepping for university physics qualifier"
  }
 ],
 "contacts": [
  {
   "id": "c-1",
   "student_id": "borna",
   "email": "borna.curic09@gmail.com",
   "label": "student",
   "receives_meets": true,
   "receives_reports": true,
   "receives_invoices": false,
   "receives_assignments": true,
   "can_login": true
  },
  {
   "id": "c-2",
   "student_id": "borna",
   "email": "parent.curic@gmail.com",
   "label": "parent",
   "receives_meets": true,
   "receives_reports": true,
   "receives_invoices": true,
   "receives_assignments": false,
   "can_login": false
  }
 ],
 "handouts": [
  {
   "id": "h-1",
   "contest": "Eichenlaub",
   "type": "Handout",
   "year": 0,
   "label": "",
   "name": "Dimensional Analysis: A Working Guide",
   "desc": "Notes and worked examples on using scaling arguments to check and even derive results.",
   "topic": "Mechanics",
   "tags": [
    "dimensional analysis",
    "problem solving"
   ],
   "problemUrl": "#",
   "solutionUrl": null
  },
  {
   "id": "h-2",
   "contest": "Morin",
   "type": "Book",
   "year": 0,
   "label": "",
   "name": "Introduction to Classical Mechanics",
   "desc": "Reference text. Chapters 8–10 for rotational dynamics.",
   "topic": "Mechanics",
   "tags": [
    "textbook",
    "mechanics"
   ],
   "problemUrl": "#",
   "solutionUrl": null
  },
  {
   "id": "h-3",
   "contest": "Eichenlaub",
   "type": "Handout",
   "year": 0,
   "label": "",
   "name": "Error Propagation Cheat Sheet",
   "desc": "One-page reference for combining uncertainties in lab write-ups.",
   "topic": "Experimental Methods",
   "tags": [
    "error analysis",
    "experimental methods"
   ],
   "problemUrl": "#",
   "solutionUrl": null
  }
 ]
};
