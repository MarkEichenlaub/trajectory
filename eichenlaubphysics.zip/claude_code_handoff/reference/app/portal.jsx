// Student portal — Assigned / Completed / All / Sessions / Account.
const { useState: useStateP, useMemo: useMemoP } = React;

function ProblemRow({ a, p }) {
  const isResource = p.type === 'Book' || p.type === 'Handout';
  const linkLabel = p.type === 'Book' ? 'Book' : p.type === 'Handout' ? 'Handout' : 'Problem';
  const dateLabel = a.status === 'completed' && a.completed_date
    ? `Completed ${fmtDate(a.completed_date, { month: 'short', day: 'numeric' })}`
    : `Assigned ${fmtDate(a.assigned_date, { month: 'short', day: 'numeric' })}`;
  return (
    <div className="row">
      <span className={`badge ${a.status}`}>
        {a.status === 'assigned' ? '→ Assigned' : '✓ Completed'}
      </span>
      <div className="row-info">
        <span className="lab">{p.contest}{!isResource ? ` ${p.year} ${p.label}` : ''}</span>
        <span className="nm">{p.name}</span>
        {a.notes ? <span className="note">{a.notes}</span> : null}
        <span className="dt" style={{ marginLeft: 'auto' }}>{dateLabel}</span>
      </div>
      <div className="row-links">
        <a className="lnk" href={p.problemUrl} target="_blank" rel="noreferrer">{linkLabel} <Icon name="ext" size={12} /></a>
        {p.solutionUrl ? <a className="lnk" href={p.solutionUrl} target="_blank" rel="noreferrer">Solution <Icon name="ext" size={12} /></a> : null}
      </div>
    </div>
  );
}

function SessionsTab({ sessions }) {
  const [selTags, setSelTags] = useStateP(new Set());
  const sorted = useMemoP(() => [...sessions].sort((a, b) => b.scheduled_at.localeCompare(a.scheduled_at)), [sessions]);
  const now = new Date().toISOString();
  const past = sorted.filter(s => s.scheduled_at <= now);
  const next = [...sessions].filter(s => s.scheduled_at > now).sort((a, b) => a.scheduled_at.localeCompare(b.scheduled_at))[0];

  const counts = {};
  past.forEach(s => (s.tags || []).forEach(t => { counts[t] = (counts[t] || 0) + 1; }));
  const tagList = Object.entries(counts).sort((a, b) => b[1] - a[1]);

  const shown = selTags.size === 0 ? past : past.filter(s => [...selTags].every(t => (s.tags || []).includes(t)));
  function toggle(t) { setSelTags(p => { const n = new Set(p); n.has(t) ? n.delete(t) : n.add(t); return n; }); }

  return (
    <div>
      {next && (
        <div className="row session-up" style={{ marginBottom: 22, padding: '14px 18px' }}>
          <span className="badge neutral" style={{ background: 'var(--surface)' }}><Icon name="cal" size={12} /> Next session</span>
          <div className="row-info">
            <span className="nm" style={{ fontFamily: 'var(--font-display)', fontSize: 15.5 }}>{fmtDateTime(next.scheduled_at)}</span>
            <span className="dt">{relDay(next.scheduled_at)}</span>
          </div>
          <span className="mono" style={{ fontSize: 12, color: 'var(--accent)' }}>Confirmed</span>
        </div>
      )}

      <div style={{ display: 'flex', gap: 24, alignItems: 'flex-start' }}>
        {tagList.length > 0 && (
          <div className="card" style={{ width: 192, flexShrink: 0, padding: '14px 0', position: 'sticky', top: 0 }}>
            <div style={{ padding: '0 14px 10px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span className="eyebrow">Topics</span>
              {selTags.size > 0 && <button className="btn sm ghost" style={{ padding: '2px 6px', fontSize: 11 }} onClick={() => setSelTags(new Set())}>Clear</button>}
            </div>
            {tagList.map(([t, c]) => (
              <div key={t} onClick={() => toggle(t)} className="side-item" style={{ borderLeftColor: selTags.has(t) ? 'var(--accent)' : 'transparent', background: selTags.has(t) ? 'var(--accent-soft)' : 'transparent', color: selTags.has(t) ? 'var(--accent)' : 'var(--ink-soft)' }}>
                <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t}</span>
                <span className="ct">{c}</span>
              </div>
            ))}
          </div>
        )}
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 12, minWidth: 0 }}>
          {shown.length === 0 ? <div className="empty">No sessions match these topics.</div> : shown.map(s => (
            <div key={s.id} className="card session-card">
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
                <span className="when">{fmtDate(s.scheduled_at)}</span>
                <div style={{ display: 'flex', gap: 14 }}>
                  {s.miro_board_url && <a className="lnk" href={s.miro_board_url} target="_blank" rel="noreferrer">Whiteboard <Icon name="ext" size={12} /></a>}
                  {s.miro_pdf_url && <a className="lnk" href={s.miro_pdf_url} target="_blank" rel="noreferrer">PDF <Icon name="ext" size={12} /></a>}
                </div>
              </div>
              {s.summary && <p className="summary">{s.summary}</p>}
              {(s.tags || []).length > 0 && (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                  {s.tags.map(t => <span key={t} className={`chip clickable ${selTags.has(t) ? 'active' : ''}`} onClick={() => toggle(t)}>{t}</span>)}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

const TOGGLES = [['receives_meets', 'Meet invites'], ['receives_reports', 'Progress reports'], ['receives_invoices', 'Invoices'], ['receives_assignments', 'Assignments']];

function AccountTab({ contacts: initial }) {
  const [contacts, setContacts] = useStateP(initial);
  const [email, setEmail] = useStateP('');
  function toggle(id, field) { setContacts(cs => cs.map(c => c.id === id ? { ...c, [field]: !c[field] } : c)); }
  function add() {
    if (!email.trim()) return;
    setContacts(cs => [...cs, { id: 'n' + Date.now(), email: email.trim(), label: 'parent', receives_meets: true, receives_reports: true, receives_invoices: false, receives_assignments: false }]);
    setEmail('');
  }
  return (
    <div style={{ maxWidth: 720 }}>
      <h3 style={{ fontFamily: 'var(--font-ui)', fontSize: 14.5, fontWeight: 600, marginBottom: 14 }}>Email addresses</h3>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 18 }}>
        {contacts.map(c => (
          <div key={c.id} className="card" style={{ padding: '13px 16px', display: 'flex', alignItems: 'center', gap: 14, flexWrap: 'wrap' }}>
            <div style={{ flex: 1, minWidth: 160 }}>
              <div style={{ fontSize: 13.5, fontWeight: 500 }}>{c.email}</div>
              <div className="mono" style={{ fontSize: 11, color: 'var(--muted)', marginTop: 2 }}>{c.label}</div>
            </div>
            <div style={{ display: 'flex', gap: 16, flexWrap: 'wrap' }}>
              {TOGGLES.map(([f, label]) => (
                <label key={f} style={{ display: 'flex', alignItems: 'center', gap: 5, cursor: 'pointer', fontSize: 12.5, color: c[f] ? 'var(--accent)' : 'var(--muted)' }}>
                  <input type="checkbox" checked={!!c[f]} onChange={() => toggle(c.id, f)} /> {label}
                </label>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <input type="email" value={email} onChange={e => setEmail(e.target.value)} onKeyDown={e => e.key === 'Enter' && add()} placeholder="email@example.com" style={{ flex: 1 }} />
        <button className="btn primary" onClick={add}><Icon name="plus" size={14} /> Add</button>
      </div>
      <p style={{ fontSize: 12.5, color: 'var(--muted)', marginTop: 12, lineHeight: 1.6 }}>
        Added addresses receive the selected communications but can't sign in to this portal. Ask Mark to enable login access for an email.
      </p>
    </div>
  );
}

function StudentPortal({ student, data, onSignOut }) {
  const [tab, setTab] = useStateP('assigned');
  const byId = useMemoP(() => Object.fromEntries(data.problems.concat(data.handouts).map(p => [p.id, p])), [data]);
  const mine = data.assignments.filter(a => a.student_id === student.id);
  const assigned = mine.filter(a => a.status === 'assigned').sort((a, b) => (b.assigned_date || '').localeCompare(a.assigned_date || ''));
  const completed = mine.filter(a => a.status === 'completed').sort((a, b) => (b.completed_date || '').localeCompare(a.completed_date || ''));
  const all = [...assigned, ...completed];
  const sessions = data.sessions.filter(s => s.student_id === student.id);
  const pastSessions = sessions.filter(s => s.scheduled_at <= new Date().toISOString());

  const tabs = [['assigned', 'Assigned', assigned.length], ['completed', 'Completed', completed.length], ['all', 'All problems', all.length], ['sessions', 'Sessions', pastSessions.length], ['account', 'Account', null]];
  const items = tab === 'assigned' ? assigned : tab === 'completed' ? completed : all;

  return (
    <div className="app">
      <div className="topbar">
        <Wordmark sub="Student Portal" />
        <div className="spacer" />
        <span style={{ fontSize: 13.5, color: 'var(--ink-soft)' }}>{student.name}</span>
        <button className="btn sm ghost" onClick={onSignOut}>Sign out</button>
      </div>
      <div className="content">
        <div className="workspace scroll" style={{ width: '100%' }}>
          <div className="work-pad" style={{ maxWidth: 940, margin: '0 auto' }}>
            <div style={{ marginBottom: 22 }}>
              <h1 style={{ fontSize: 27, marginBottom: 6 }}>Welcome back, {student.name}</h1>
              <p style={{ fontSize: 14, color: 'var(--muted)', fontFamily: 'var(--font-mono)' }}>
                {assigned.length} assigned · {completed.length} completed · {pastSessions.length} sessions
              </p>
            </div>
            <div className="tabs">
              {tabs.map(([k, label, c]) => (
                <button key={k} className={tab === k ? 'active' : ''} onClick={() => setTab(k)}>
                  {label}{c != null && <span className="tc">{c}</span>}
                </button>
              ))}
            </div>

            {tab === 'account' ? <AccountTab contacts={data.contacts.filter(c => c.student_id === student.id)} />
              : tab === 'sessions' ? (sessions.length === 0 ? <div className="empty">No sessions yet.</div> : <SessionsTab sessions={sessions} />)
              : items.length === 0 ? <div className="empty"><div className="em-mk">○</div>{tab === 'assigned' ? 'No problems currently assigned.' : tab === 'completed' ? 'No completed problems yet.' : 'No problems yet.'}</div>
              : <div className="list">{items.map(a => { const p = byId[a.problem_id]; return p ? <ProblemRow key={a.id} a={a} p={p} /> : null; })}</div>}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { StudentPortal });
