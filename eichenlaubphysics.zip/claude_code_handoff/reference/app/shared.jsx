// Shared: brand mark, icons, formatters, toast. Exposed on window.
const { useState, useEffect, useRef, useMemo, useCallback } = React;

/* Brand glyph — a minimal "branching node" echoing the circuit-tree logo.
   Simple circles + lines only. */
function BrandMark({ size = 18, color = 'currentColor' }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none"
         stroke={color} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 21 L12 13" />
      <path d="M12 13 L6 8" />
      <path d="M12 13 L18 8" />
      <path d="M12 13 L12 5" />
      <circle cx="12" cy="13" r="2.1" fill={color} stroke="none" />
      <circle cx="6" cy="8" r="1.5" fill={color} stroke="none" />
      <circle cx="18" cy="8" r="1.5" fill={color} stroke="none" />
      <circle cx="12" cy="4.4" r="1.5" fill={color} stroke="none" />
    </svg>
  );
}

function Wordmark({ sub }) {
  return (
    <div className="wordmark">
      <span className="mark"><BrandMark size={17} color="var(--accent-ink)" /></span>
      <span>
        <span className="wm-name" style={{ display: 'block' }}>Eichenlaub Physics</span>
        {sub && <span className="wm-sub" style={{ display: 'block' }}>{sub}</span>}
      </span>
    </div>
  );
}

function Icon({ name, size = 16, stroke = 1.6 }) {
  const common = { width: size, height: size, viewBox: '0 0 24 24', fill: 'none',
    stroke: 'currentColor', strokeWidth: stroke, strokeLinecap: 'round', strokeLinejoin: 'round' };
  const paths = {
    search: <><circle cx="11" cy="11" r="7" /><path d="m20 20-3.5-3.5" /></>,
    check: <path d="M5 12.5 10 17.5 19.5 7" />,
    arrow: <path d="M5 12h14M13 6l6 6-6 6" />,
    ext: <><path d="M14 5h5v5" /><path d="M19 5l-8 8" /><path d="M18 14v4a1 1 0 0 1-1 1H6a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h4" /></>,
    cal: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M3 9h18M8 3v4M16 3v4" /></>,
    clock: <><circle cx="12" cy="12" r="9" /><path d="M12 7v5l3 2" /></>,
    book: <><path d="M5 4h11a2 2 0 0 1 2 2v14H7a2 2 0 0 1-2-2z" /><path d="M5 18a2 2 0 0 1 2-2h11" /></>,
    plus: <path d="M12 5v14M5 12h14" />,
    x: <path d="M6 6l12 12M18 6 6 18" />,
    mail: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="m3 7 9 6 9-6" /></>,
    user: <><circle cx="12" cy="8" r="4" /><path d="M4 20c0-4 4-6 8-6s8 2 8 6" /></>,
    board: <><rect x="3" y="4" width="18" height="13" rx="2" /><path d="M8 21h8M12 17v4" /></>,
    grip: <><circle cx="9" cy="6" r="1.3" fill="currentColor" stroke="none"/><circle cx="15" cy="6" r="1.3" fill="currentColor" stroke="none"/><circle cx="9" cy="12" r="1.3" fill="currentColor" stroke="none"/><circle cx="15" cy="12" r="1.3" fill="currentColor" stroke="none"/><circle cx="9" cy="18" r="1.3" fill="currentColor" stroke="none"/><circle cx="15" cy="18" r="1.3" fill="currentColor" stroke="none"/></>,
    spark: <><path d="M12 3v4M12 17v4M3 12h4M17 12h4M6 6l2.5 2.5M15.5 15.5 18 18M18 6l-2.5 2.5M8.5 15.5 6 18"/></>,
  };
  return <svg {...common}>{paths[name]}</svg>;
}

const CONTESTS_FULL = {
  IPhO: 'International Physics Olympiad',
  USAPhO: 'U.S. Physics Olympiad',
  EuPhO: 'European Physics Olympiad',
  Balkan: 'Balkan Physics Olympiad',
  NordicBalkan: 'Nordic-Baltic Olympiad',
};

function fmtDate(iso, opts) {
  const d = new Date(iso);
  return d.toLocaleDateString('en-US', opts || { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' });
}
function fmtDateTime(iso) {
  return new Date(iso).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
}
function relDay(iso) {
  const d = new Date(iso); const now = new Date();
  const days = Math.round((d - now) / 86400000);
  if (days === 0) return 'today';
  if (days === 1) return 'tomorrow';
  if (days > 1 && days < 7) return `in ${days} days`;
  if (days === -1) return 'yesterday';
  if (days < 0 && days > -7) return `${-days} days ago`;
  return fmtDate(iso, { month: 'short', day: 'numeric' });
}

function useToast() {
  const [toast, setToast] = useState(null);
  const show = useCallback((msg) => {
    setToast(msg);
    clearTimeout(useToast._t);
    useToast._t = setTimeout(() => setToast(null), 2600);
  }, []);
  const node = toast ? <div className="toast">{toast}</div> : null;
  return [show, node];
}

Object.assign(window, {
  BrandMark, Wordmark, Icon, CONTESTS_FULL, fmtDate, fmtDateTime, relDay, useToast,
});
