// Admin (Trajectory) — shell, filter sidebar, problem browser.
const { useState: useStateA, useMemo: useMemoA } = React;

const TOPIC_ORDER = ['Mechanics', 'Electromagnetism', 'Waves & Oscillations', 'Optics', 'Thermodynamics', 'Quantum Physics', 'Relativity', 'Nuclear/Particle', 'Astrophysics', 'Experimental Methods'];
const STATUS_OPTS = [['not-started', 'Not started'], ['assigned', 'Assigned'], ['completed', 'Completed']];

function SideSection({ title, action, children, defaultOpen = true }) {
  const [open, setOpen] = useStateA(defaultOpen);
  return (
    <div className="side-section">
      <div className="side-head" onClick={() => setOpen(o => !o)}>
        <span className="t">{title}</span>
        <span style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          {action && <span onClick={e => e.stopPropagation()}>{action}</span>}
          <span className="caret" style={{ transform: open ? 'rotate(0)' : 'rotate(-90deg)' }}>▼</span>
        </span>
      </div>
      {open && <div className="side-body">{children}</div>}
    </div>
  );
}

function FilterSidebar({ problems, filtered, filters, setF, statusMap }) {
  const [tagSearch, setTagSearch] = useStateA('');
  const contests = useMemoA(() => [...new Set(problems.map(p => p.contest))].sort(), [problems]);
  const types = useMemoA(() => [...new Set(problems.map(p => p.type))].sort(), [problems]);
  const count = (sel) => filtered.reduce((m, p) => { sel(p).forEach(k => m[k] = (m[k] || 0) + 1); return m; }, {});
  const cContest = useMemoA(() => count(p => [p.contest]), [filtered]);
  const cType = useMemoA(() => count(p => [p.type]), [filtered]);
  const cTopic = useMemoA(() => count(p => [p.topic]), [filtered]);
  const cStatus = useMemoA(() => filtered.reduce((m, p) => { const s = statusMap[p.id] || 'not-started'; m[s] = (m[s] || 0) + 1; return m; }, {}), [filtered, statusMap]);
  const tagCounts = useMemoA(() => { const m = {}; filtered.forEach(p => (p.tags || []).forEach(t => m[t] = (m[t] || 0) + 1)); return Object.entries(m).sort((a, b) => b[1] - a[1]); }, [filtered]);
  const tags = tagSearch ? tagCounts.filter(([t]) => t.toLowerCase().includes(tagSearch.toLowerCase())) : tagCounts;

  function toggleSet(key, v) { setF(p => { const n = new Set(p[key]); n.has(v) ? n.delete(v) : n.add(v); return { ...p, [key]: n }; }); }
  const hasFilter = filters.contests.size || filters.types.size || filters.topics.size || filters.statuses.size || filters.selectedTags.size || filters.hideCompleted;
  function clearAll() { setF(p => ({ ...p, contests: new Set(), types: new Set(), topics: new Set(), statuses: new Set(), selectedTags: new Set(), hideCompleted: false })); }

  const Item = ({ on, label, ct, onClick }) => (
    <div className={`side-item ${on ? 'active' : ''}`} onClick={onClick}>
      <input type="checkbox" checked={on} readOnly />
      <span>{label}</span>{ct != null && <span className="ct">{ct}</span>}
    </div>
  );

  return (
    <div className="sidebar">
      <div className="side-head" style={{ paddingBottom: 4 }}>
        <span className="t">Filters</span>
        {hasFilter ? <button className="btn sm ghost" style={{ padding: '2px 8px', fontSize: 11 }} onClick={clearAll}>Clear all</button> : null}
      </div>
      <div className="side-item" onClick={() => setF(p => ({ ...p, hideCompleted: !p.hideCompleted }))}>
        <input type="checkbox" checked={filters.hideCompleted} readOnly /><span>Hide completed</span>
      </div>
      <SideSection title="Source">
        {contests.map(c => <Item key={c} on={filters.contests.has(c)} label={c} ct={cContest[c] || 0} onClick={() => toggleSet('contests', c)} />)}
      </SideSection>
      <SideSection title="Type">
        {types.map(t => <Item key={t} on={filters.types.has(t)} label={t} ct={cType[t] || 0} onClick={() => toggleSet('types', t)} />)}
      </SideSection>
      <SideSection title="Topic">
        {TOPIC_ORDER.filter(t => cTopic[t] > 0 || filters.topics.has(t)).map(t => <Item key={t} on={filters.topics.has(t)} label={t} ct={cTopic[t] || 0} onClick={() => toggleSet('topics', t)} />)}
      </SideSection>
      <SideSection title="Status" defaultOpen={false}>
        {STATUS_OPTS.map(([k, l]) => <Item key={k} on={filters.statuses.has(k)} label={l} ct={cStatus[k] || 0} onClick={() => toggleSet('statuses', k)} />)}
      </SideSection>
      <SideSection title={`Tags${filters.selectedTags.size ? ` (${filters.selectedTags.size})` : ''}`} defaultOpen={false}
        action={filters.selectedTags.size ? <button className="btn sm ghost" style={{ padding: '2px 6px', fontSize: 11 }} onClick={() => setF(p => ({ ...p, selectedTags: new Set() }))}>Clear</button> : null}>
        <div className="side-search"><input placeholder="Search tags…" value={tagSearch} onChange={e => setTagSearch(e.target.value)} /></div>
        {tags.slice(0, 60).map(([t, c]) => (
          <div key={t} className={`side-item ${filters.selectedTags.has(t) ? 'active' : ''}`} style={{ fontSize: 12.5 }} onClick={() => toggleSet('selectedTags', t)}>
            <span style={{ flex: 1, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{t}</span><span className="ct">{c}</span>
          </div>
        ))}
      </SideSection>
    </div>
  );
}

const COLS = [['status', 'Status', 80], ['year', 'Year', 60], ['label', '#', 48], ['name', 'Problem', null], ['topics', 'Topic', 170], ['links', 'Links', 100]];

function ProblemBrowser({ allProblems, filters, setF, statusMap, selected, setSelected, sort, setSort, student, onAssign }) {
  const pre = useMemoA(() => allProblems.filter(p => {
    if (filters.contests.size && !filters.contests.has(p.contest)) return false;
    if (filters.types.size && !filters.types.has(p.type)) return false;
    if (filters.topics.size && !filters.topics.has(p.topic)) return false;
    if (filters.hideCompleted && statusMap[p.id] === 'completed') return false;
    if (filters.statuses.size && !filters.statuses.has(statusMap[p.id] || 'not-started')) return false;
    if (filters.textSearch) {
      const q = filters.textSearch.toLowerCase();
      if (!p.name.toLowerCase().includes(q) && !p.desc.toLowerCase().includes(q) && !(p.tags || []).some(t => t.toLowerCase().includes(q)) && !String(p.year).includes(q) && !(p.country || '').toLowerCase().includes(q)) return false;
    }
    return true;
  }), [allProblems, filters, statusMap]);
  const filtered = useMemoA(() => filters.selectedTags.size === 0 ? pre : pre.filter(p => [...filters.selectedTags].every(t => (p.tags || []).includes(t))), [pre, filters.selectedTags]);
  const sorted = useMemoA(() => {
    const ord = { assigned: 0, 'not-started': 1, completed: 2 };
    return [...filtered].sort((a, b) => {
      let av, bv;
      if (sort.col === 'status') { av = ord[statusMap[a.id] || 'not-started']; bv = ord[statusMap[b.id] || 'not-started']; }
      else { av = a[sort.col]; bv = b[sort.col]; if (sort.col === 'name') { av = (av || '').toLowerCase(); bv = (bv || '').toLowerCase(); } }
      if (av < bv) return sort.dir === 'asc' ? -1 : 1;
      if (av > bv) return sort.dir === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filtered, sort, statusMap]);

  function doSort(col) { setSort(s => s.col === col ? { col, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { col, dir: 'asc' }); }
  function toggle(id) { setSelected(s => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n; }); }
  const allSel = sorted.length > 0 && sorted.every(p => selected.has(p.id));

  return (
    <>
      <FilterSidebar problems={allProblems} filtered={pre} filters={filters} setF={setF} statusMap={statusMap} />
      <div className="panel">
        {selected.size > 0 && (
          <div className="bar action-bar">
            <span className="sel">{selected.size} selected</span>
            <button className="btn sm" onClick={() => setSelected(new Set())}>Clear</button>
            <button className="btn sm" onClick={() => setSelected(new Set(sorted.map(p => p.id)))}>Select all {sorted.length}</button>
            <div className="spacer" />
            <button className="btn sm primary" onClick={() => onAssign([...selected])}>Assign to {student.name}</button>
          </div>
        )}
        <div className="bar">
          <span style={{ color: 'var(--muted)', display: 'flex' }}><Icon name="search" size={16} /></span>
          <input className="search" placeholder="Search problems, tags, countries…" value={filters.textSearch} onChange={e => setF(p => ({ ...p, textSearch: e.target.value }))} />
          <div className="spacer" />
          <span className="count">{sorted.length} problem{sorted.length !== 1 ? 's' : ''}</span>
        </div>
        <div className="tbl-wrap">
          <table>
            <thead>
              <tr>
                <th style={{ width: 34 }}><input type="checkbox" checked={allSel} onChange={() => setSelected(allSel ? new Set() : new Set(sorted.map(p => p.id)))} /></th>
                {COLS.map(([k, l, w]) => (
                  <th key={k} style={w ? { width: w } : undefined} onClick={() => ['status', 'year', 'label', 'name'].includes(k) && doSort(k)}>
                    {l}{sort.col === k && <span className="sort">{sort.dir === 'asc' ? '▲' : '▼'}</span>}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sorted.map(p => {
                const st = statusMap[p.id];
                const sel = selected.has(p.id);
                const isRes = p.type === 'Book' || p.type === 'Handout';
                return (
                  <tr key={p.id} className={sel ? 'sel' : st === 'completed' ? 'is-done' : st === 'assigned' ? 'is-assigned' : ''} onClick={() => toggle(p.id)} style={{ cursor: 'pointer' }}>
                    <td onClick={e => e.stopPropagation()}><input type="checkbox" checked={sel} onChange={() => toggle(p.id)} /></td>
                    <td>{st === 'assigned' ? <span className="badge assigned">→ Assigned</span> : st === 'completed' ? <span className="badge completed">✓ Done</span> : null}</td>
                    <td className="p-meta">{isRes ? <span style={{ color: 'var(--accent)' }}>{p.contest}</span> : p.year}</td>
                    <td className="p-meta">{!isRes ? p.label : ''}</td>
                    <td><div className="p-name">{p.name}</div><div className="p-desc">{p.desc}</div></td>
                    <td><span className="chip topic">{p.topic}</span></td>
                    <td onClick={e => e.stopPropagation()}>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                        {p.problemUrl && <a className="lnk" href={p.problemUrl} target="_blank" rel="noreferrer">{isRes ? 'PDF' : 'Problem'} <Icon name="ext" size={11} /></a>}
                        {p.solutionUrl && <a className="lnk" href={p.solutionUrl} target="_blank" rel="noreferrer">Solution <Icon name="ext" size={11} /></a>}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {sorted.length === 0 && <div className="empty">No problems match the current filters.</div>}
        </div>
      </div>
    </>
  );
}

Object.assign(window, { ProblemBrowser, TOPIC_ORDER });
