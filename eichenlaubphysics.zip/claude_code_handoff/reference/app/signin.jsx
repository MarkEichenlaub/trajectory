// Student sign-in — magic-link style, unified brand.
const { useState: useStateS } = React;

function SignIn({ onBack, onSignedIn }) {
  const [email, setEmail] = useStateS('');
  const [sent, setSent] = useStateS(false);

  return (
    <div style={{ height: '100vh', display: 'grid', placeItems: 'center', background: 'var(--bg)', padding: 24 }}>
      <div style={{ width: '100%', maxWidth: 400 }}>
        <button className="btn sm ghost" onClick={onBack} style={{ marginBottom: 18 }}>‹ Back to site</button>
        <div className="card" style={{ padding: '38px 36px', textAlign: 'center', borderRadius: 'var(--r-xl)' }}>
          <div style={{ width: 46, height: 46, borderRadius: 12, background: 'var(--accent)', display: 'grid', placeItems: 'center', margin: '0 auto 16px', boxShadow: 'var(--shadow-md)' }}>
            <BrandMark size={26} color="var(--accent-ink)" />
          </div>
          <h2 style={{ fontSize: 22, marginBottom: 6 }}>Student Portal</h2>

          {!sent ? (
            <>
              <p style={{ fontSize: 13.5, color: 'var(--muted)', marginBottom: 24 }}>
                Sign in to see your assignments and session notes.
              </p>
              <form onSubmit={(e) => { e.preventDefault(); if (email.trim()) setSent(true); }}
                    style={{ textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 14 }}>
                <label style={{ fontSize: 12.5 }}>
                  <span style={{ display: 'block', marginBottom: 6, color: 'var(--ink-soft)' }}>Your email address</span>
                  <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                         placeholder="you@example.com" required autoFocus style={{ width: '100%' }} />
                </label>
                <button type="submit" className="btn primary block" style={{ padding: '10px' }}>Send login link</button>
              </form>
              <p style={{ fontSize: 12, color: 'var(--muted)', marginTop: 18, lineHeight: 1.6 }}>
                We'll email you a secure one-time link — no password to remember.
              </p>
            </>
          ) : (
            <>
              <div style={{ width: 50, height: 50, borderRadius: '50%', background: 'var(--accent-soft)', color: 'var(--accent)', display: 'grid', placeItems: 'center', margin: '6px auto 16px' }}>
                <Icon name="mail" size={24} />
              </div>
              <p style={{ fontSize: 14.5, color: 'var(--ink)', lineHeight: 1.6, marginBottom: 8 }}>
                Check your email for a login link.
              </p>
              <p style={{ fontSize: 12.5, color: 'var(--muted)', lineHeight: 1.6, marginBottom: 22 }}>
                The link expires after 1 hour. Check spam if you don't see it.
              </p>
              {/* demo shortcut */}
              <button className="btn primary block" onClick={onSignedIn}>
                <Icon name="arrow" size={15} /> Open Borna's portal (demo)
              </button>
              <button className="btn ghost block" style={{ marginTop: 8 }} onClick={() => setSent(false)}>Use a different email</button>
            </>
          )}
        </div>
        <p style={{ textAlign: 'center', fontSize: 12, color: 'var(--muted)', marginTop: 16 }}>
          Eichenlaub Physics · <a href="mailto:mark@eichenlaubphysics.com">mark@eichenlaubphysics.com</a>
        </p>
      </div>
    </div>
  );
}

Object.assign(window, { SignIn });
