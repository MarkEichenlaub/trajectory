// Public booking page — unified brand, with an interactive month-view booking widget.
const { useState: useStateB, useMemo: useMemoB } = React;

function BookingCalendar() {
  const today = new Date(2026, 4, 29); // May 29 2026
  const [month, setMonth] = useStateB({ y: 2026, m: 4 });
  const [picked, setPicked] = useStateB(null);
  const [time, setTime] = useStateB(null);
  const [done, setDone] = useStateB(false);

  const monthName = new Date(month.y, month.m, 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  const firstDow = new Date(month.y, month.m, 1).getDay();
  const daysIn = new Date(month.y, month.m + 1, 0).getDate();

  // deterministic "availability": weekdays + some weekends, from tomorrow onward
  function avail(day) {
    const d = new Date(month.y, month.m, day);
    const dow = d.getDay();
    if (d <= today) return false;
    if (dow === 0) return false;            // closed Sundays
    if (dow === 6) return day % 2 === 0;    // some Saturdays
    return true;
  }

  const slots = ['9:00 am', '10:30 am', '1:00 pm', '2:30 pm', '4:00 pm', '5:30 pm'];

  const cells = [];
  for (let i = 0; i < firstDow; i++) cells.push(null);
  for (let d = 1; d <= daysIn; d++) cells.push(d);

  function pickDay(d) { setPicked(d); setTime(null); setDone(false); }

  const pickedLabel = picked
    ? new Date(month.y, month.m, picked).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' })
    : null;

  return (
    <div className="card" style={{ overflow: 'hidden', display: 'grid', gridTemplateColumns: picked ? '1.4fr 1fr' : '1fr', maxWidth: 760, margin: '0 auto' }}>
      {/* calendar */}
      <div style={{ padding: '22px 24px', borderRight: picked ? '1px solid var(--rule)' : 'none' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 16 }}>
          <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 18 }}>{monthName}</div>
          <div style={{ display: 'flex', gap: 4 }}>
            <button className="btn sm ghost" onClick={() => setMonth(m => ({ y: m.m === 0 ? m.y - 1 : m.y, m: (m.m + 11) % 12 }))} aria-label="Previous month">‹</button>
            <button className="btn sm ghost" onClick={() => setMonth(m => ({ y: m.m === 11 ? m.y + 1 : m.y, m: (m.m + 1) % 12 }))} aria-label="Next month">›</button>
          </div>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(7,1fr)', gap: 4 }}>
          {['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'].map(d => (
            <div key={d} style={{ textAlign: 'center', fontFamily: 'var(--font-mono)', fontSize: 11, color: 'var(--muted)', padding: '4px 0', letterSpacing: '.04em' }}>{d}</div>
          ))}
          {cells.map((d, i) => {
            if (!d) return <div key={'e' + i} />;
            const ok = avail(d);
            const isPicked = picked === d;
            return (
              <button key={d} disabled={!ok} onClick={() => pickDay(d)}
                style={{
                  aspectRatio: '1', border: '1px solid', borderRadius: 8, cursor: ok ? 'pointer' : 'default',
                  fontFamily: 'var(--font-mono)', fontSize: 14, fontWeight: ok ? 600 : 400,
                  background: isPicked ? 'var(--accent)' : ok ? 'var(--surface)' : 'transparent',
                  color: isPicked ? 'var(--accent-ink)' : ok ? 'var(--ink)' : 'var(--muted)',
                  borderColor: isPicked ? 'var(--accent)' : ok ? 'var(--rule-strong)' : 'transparent',
                  opacity: ok ? 1 : .4, transition: 'background .12s, border-color .12s',
                }}>
                {d}
              </button>
            );
          })}
        </div>
        <div style={{ marginTop: 14, display: 'flex', alignItems: 'center', gap: 7, fontSize: 12, color: 'var(--muted)' }}>
          <span style={{ width: 9, height: 9, borderRadius: 3, background: 'var(--surface)', border: '1px solid var(--rule-strong)' }} />
          Available · 60-minute session · times shown in your local zone
        </div>
      </div>

      {/* time slots / confirmation */}
      {picked && (
        <div style={{ padding: '22px 22px', background: 'var(--bg-tint)' }}>
          {!done ? (
            <>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 15, marginBottom: 2 }}>{pickedLabel}</div>
              <div className="eyebrow" style={{ marginBottom: 14 }}>Select a time</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 7, maxHeight: 250, overflowY: 'auto' }} className="scroll">
                {slots.map(s => (
                  <button key={s} onClick={() => setTime(s)}
                    style={{
                      padding: '10px 12px', borderRadius: 8, fontFamily: 'var(--font-mono)', fontSize: 13.5, fontWeight: 500,
                      cursor: 'pointer', textAlign: 'center', transition: 'all .12s',
                      border: '1px solid', borderColor: time === s ? 'var(--accent)' : 'var(--rule-strong)',
                      background: time === s ? 'var(--accent)' : 'var(--surface)',
                      color: time === s ? 'var(--accent-ink)' : 'var(--ink)',
                    }}>
                    {s}
                  </button>
                ))}
              </div>
              <button className="btn primary block" style={{ marginTop: 16 }} disabled={!time} onClick={() => setDone(true)}>
                {time ? `Confirm ${time}` : 'Pick a time'}
              </button>
            </>
          ) : (
            <div style={{ textAlign: 'center', padding: '24px 4px' }}>
              <div style={{ width: 46, height: 46, borderRadius: '50%', background: 'var(--done-bg)', border: '1px solid var(--done-line)', color: 'var(--done-ink)', display: 'grid', placeItems: 'center', margin: '0 auto 14px' }}>
                <Icon name="check" size={24} />
              </div>
              <div style={{ fontFamily: 'var(--font-display)', fontWeight: 600, fontSize: 17, marginBottom: 6 }}>Session requested</div>
              <p style={{ fontSize: 13.5, color: 'var(--ink-soft)', lineHeight: 1.6 }}>
                {pickedLabel} at {time}. You'll get a confirmation email with a video link, and the session will appear in your student portal.
              </p>
              <button className="btn block" style={{ marginTop: 16 }} onClick={() => { setPicked(null); setTime(null); setDone(false); }}>Book another</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function BookingPage({ onSignIn }) {
  const focus = ['Olympiad training', 'Research projects', 'Advanced coursework', 'Standardized tests', 'Qualification exams', 'Self-study'];
  return (
    <div className="scroll" style={{ height: '100vh', overflowY: 'auto', background: 'var(--bg)' }}>
      {/* public header */}
      <header style={{ position: 'sticky', top: 0, zIndex: 10, background: 'color-mix(in srgb, var(--bg) 88%, transparent)', backdropFilter: 'blur(8px)', borderBottom: '1px solid var(--rule)' }}>
        <div style={{ maxWidth: 920, margin: '0 auto', padding: '13px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <Wordmark />
          <button className="btn sm" onClick={onSignIn} style={{ gap: 8 }}>
            <Icon name="user" size={15} /> Student sign in
          </button>
        </div>
      </header>

      <main style={{ maxWidth: 920, margin: '0 auto', padding: '0 24px 80px' }}>
        {/* hero */}
        <section style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 40, alignItems: 'center', padding: '46px 0 36px' }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 16 }}>Physics &amp; Mathematics Mentorship</div>
            <h1 style={{ fontSize: 'clamp(30px, 4.4vw, 46px)', lineHeight: 1.08, marginBottom: 22, letterSpacing: '-0.015em' }}>
              Problem-solving as a collaborative, creative act.
            </h1>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {focus.map(f => <span key={f} className="chip">{f}</span>)}
            </div>
          </div>
          <div style={{ display: 'grid', placeItems: 'center' }}>
            <div className="card" style={{ padding: 18, background: 'var(--surface)', borderRadius: 'var(--r-xl)' }}>
              <img src="logo.jpg" alt="Mark Eichenlaub Physics Mentorship" style={{ width: '100%', maxWidth: 360, display: 'block', borderRadius: 'var(--r-md)', mixBlendMode: 'multiply' }} />
            </div>
          </div>
        </section>

        <hr className="divider" style={{ margin: '8px 0 40px' }} />

        {/* booking */}
        <section>
          <div style={{ textAlign: 'center', marginBottom: 26 }}>
            <div className="eyebrow" style={{ marginBottom: 10 }}>Scheduling</div>
            <h2 style={{ fontSize: 30, marginBottom: 8 }}>Book a session</h2>
            <p style={{ fontSize: 15, color: 'var(--ink-soft)' }}>Choose a day and time that works for you. New students welcome.</p>
          </div>
          <BookingCalendar />
        </section>
      </main>

      <footer style={{ borderTop: '1px solid var(--rule)', background: 'var(--surface)' }}>
        <div style={{ maxWidth: 920, margin: '0 auto', padding: '26px 24px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 12 }}>
          <Wordmark />
          <p style={{ fontSize: 13.5, color: 'var(--muted)' }}>
            Questions? <a href="mailto:mark@eichenlaubphysics.com">mark@eichenlaubphysics.com</a>
          </p>
        </div>
      </footer>
    </div>
  );
}

Object.assign(window, { BookingPage });
