# Task for Claude Code: unify the visual design of two repos

You are updating **two existing repositories** so they share one visual brand.
A designer has already produced the new look as **finished, drop-in files**
(in this bundle) plus an interactive HTML mockup for visual reference.

Your job: apply the new design to each repo, on its own branch, verify it runs,
and open a PR. These are **presentation-only** changes — do NOT alter data
models, Supabase calls, Cal.com logic, routing, or component behavior.

## The two repos
1. **github.com/MarkEichenlaub/eichenlaubphysics-site** — static booking page (HTML/CSS + Cal.com embed). Default branch `main`.
2. **github.com/MarkEichenlaub/trajectory** — Vite + React student portal & admin. Default branch `main`.

---

## Repo 1 — eichenlaubphysics-site

Replace two files in the repo root with the versions in
`eichenlaubphysics-site/` of this bundle:

- `index.html` — adds Google Fonts links, a sticky wordmark header with a
  "Student sign in" link, an eyebrow → headline → focus-chips hero, and a
  navy-branded Cal.com embed (`cssVarsPerTheme.light["cal-brand"] = "#2a4a6d"`).
- `styles.css` — full rewrite in the unified brand.

**Action item:** the header's "Student sign in" `<a>` currently points at a
placeholder `https://trajectory.eichenlaubphysics.com`. Set it to wherever the
Trajectory app is actually deployed (ask the user if unknown).

`logo.jpg` in the bundle is just a copy of the existing committed asset — don't
re-commit it.

```
git checkout -b unified-design
# copy index.html + styles.css into the repo root
git add index.html styles.css
git commit -m "Unify visual design: warm cream + navy brand"
git push -u origin unified-design   # then open a PR
```

---

## Repo 2 — trajectory

- `src/index.css` — **full rewrite. Every original class name is preserved**,
  so NO `.jsx` files need to change. It re-skins the entire app (admin problem
  browser, assigned view, sessions, settings, student portal, login, modals,
  toasts) into the light brand. Replace the existing `src/index.css` with the
  bundle's `trajectory/src/index.css`.
- `index.html` — replace the repo-root entry file with the bundle's
  `trajectory/index.html` (adds the Google Fonts links + favicon).

```
git checkout -b unified-design
# copy index.html into repo root, src/index.css into src/
git add index.html src/index.css
git commit -m "Unify visual design with booking site: light brand re-skin"
npm install && npm run dev   # verify it renders before pushing
git push -u origin unified-design   # then open a PR
```

### Optional polish (only if the user approves)
The portal/admin topbar still renders the text `Trajectory v2`. For the
**student-facing** portal it would match the booking site better to show the
brand wordmark "Eichenlaub Physics". In `src/App.jsx` there are three
`<span className="logo">Trajectory <span …>v2</span></span>` spots — the two
inside the student-portal render paths (the `STUDENT_PARAM` branch) can be
changed to `Eichenlaub Physics`; leave the admin one as "Trajectory" since
that's Mark's internal tool. Confirm with the user before making this JS edit —
it's the only change that touches a component.

---

## Design system (for reference / any new UI)

**Fonts** (Google Fonts): Spectral (display/headings + wordmark), IBM Plex Sans
(UI/body), IBM Plex Mono (labels, metadata, problem IDs, counts, dates).

**Light palette**
| Token | Hex | Use |
|---|---|---|
| bg | `#f4efe3` | page background (warm cream) |
| surface | `#fffdf7` | cards / panels |
| surface-2 | `#f0e9da` | hover / secondary fill |
| border | `#e2d8c4` | hairline rules |
| border-strong | `#d3c7af` | input borders |
| ink / text | `#1f3a5f` | primary text (navy) |
| text-strong | `#16304f` | headings |
| text-dim | `#5a6678` | secondary text |
| muted | `#837964` | meta (warm taupe) |
| accent | `#2a4a6d` | buttons, links, active |
| accent-dim | `#e4ebf2` | tinted active/selected fills |
| accent-ink | `#fbf8f0` | text on accent |
| assigned | ink `#8a5a16` · bg `#f3e6cf` · line `#dec59a` | in-progress status |
| completed | ink `#3a6b4d` · bg `#e0ebdf` · line `#b9d2bf` | done status |

Radii ~6–8px small / 12–16px cards. Soft navy-tinted shadows
(`0 1px 2px rgba(31,58,95,.06)` etc.). The `trajectory/src/index.css` file
defines all of these as CSS custom properties — read it for exact values.

The interactive mockup also supports a **dark theme** and other accents
(teal/ochre/plum) — see `reference/`. The repos themselves are shipping the
**light + navy** default; the alternates are exploration only unless asked for.

---

## Visual reference
`reference/Eichenlaub Physics.html` is the full interactive prototype of all
four surfaces (booking, sign-in, student portal, admin). Open it in a browser
and use the **"View" pill** at the bottom to switch surfaces, and the **Tweaks**
panel to see theme/density/accent options. Treat it as the source of truth for
look & feel; the per-repo files above are the implementation of the light
default for the real codebases.
